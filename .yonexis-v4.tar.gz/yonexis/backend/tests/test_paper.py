import importlib
import os
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture
def env(tmp_path, monkeypatch):
    monkeypatch.setenv("YONEXIS_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'p.db'}")
    monkeypatch.setenv("PAPER_STARTING_BALANCE", "500000")
    monkeypatch.setenv("PAPER_SLIPPAGE_BPS", "0")
    import yonexis.config as cfg
    importlib.reload(cfg)
    import yonexis.db as db
    importlib.reload(db)
    import yonexis.broker.paper as paper
    importlib.reload(paper)
    import yonexis.broker as broker
    importlib.reload(broker)
    db.init()
    yield cfg, db, paper, broker


def test_wallet_starts_with_demo_money(env):
    cfg, db, paper, broker = env
    b = paper.PaperBroker()
    s = b.summary()
    assert s["balance"] == 500000 and s["available"] == 500000 and s["real_orders"] == "LOCKED"


def test_target_stop_and_costs_hit_wallet(env):
    cfg, db, paper, broker = env
    b = paper.PaperBroker()
    o = b.place("RELIANCE", "BUY", 100, 1000.0, 990.0, 1020.0, "t")
    assert b.summary()["available"] == 500000 - 100 * 1000
    assert b.manage({"RELIANCE": {"ltp": 1010}}, square_off=False) == []
    r = b.manage({"RELIANCE": {"ltp": 1021, "high": 1021, "low": 1012}}, square_off=False)[0]
    assert r["exit"] == "target" and r["price"] == 1020.0
    t = db.fetch(db.paper_trades)[0]
    assert t["gross_pnl"] == 2000 and 0 < t["costs"] < 100 and t["net_pnl"] == round(2000 - t["costs"], 2)
    assert b.wallet.get()["balance"] == round(500000 + t["net_pnl"], 2)
    # short that gaps through its stop fills at the worse price
    b.place("SBIN", "SELL", 50, 800.0, 805.0, 790.0, "t")
    r = b.manage({"SBIN": {"ltp": 812}}, square_off=False)[0]
    assert r["exit"] == "stop_loss" and r["price"] == 812.0


def test_stop_checked_before_target_and_square_off(env):
    cfg, db, paper, broker = env
    b = paper.PaperBroker()
    b.place("INFY", "BUY", 10, 100.0, 98.0, 104.0, "t")
    r = b.manage({"INFY": {"ltp": 101, "high": 105, "low": 97}}, square_off=False)[0]
    assert r["exit"] == "stop_loss"
    b.place("TCS", "BUY", 10, 100.0, 98.0, 104.0, "t")
    assert b.manage({"TCS": {"ltp": 101}}, square_off=True)[0]["exit"] == "square_off"


def test_insufficient_demo_funds_and_qty_capped(env):
    cfg, db, paper, broker = env
    b = paper.PaperBroker()
    o = b.place("MARUTI", "BUY", 1000, 11000.0, 10900.0, None, "t")     # wants 1.1 crore, wallet has 5 lakh
    assert o["qty"] == 45
    b.place("X", "BUY", 1, 5000.0, 4900.0, None, "t")
    with pytest.raises(paper.InsufficientFunds):
        b.place("Y", "BUY", 1, 50000.0, 49000.0, None, "t")


def test_reset_requires_flat_book(env):
    cfg, db, paper, broker = env
    b = paper.PaperBroker()
    b.place("A", "BUY", 1, 100.0, 99.0, None, "t")
    with pytest.raises(ValueError):
        b.wallet.reset(200000)
    b.square_off("A", 100.0)
    assert b.wallet.reset(200000) == 200000 and b.summary()["starting_balance"] == 200000


def test_real_orders_are_locked(env, monkeypatch):
    cfg, db, paper, broker = env
    monkeypatch.setattr(cfg.settings, "TRADING_MODE", "live")
    monkeypatch.setattr(cfg.settings, "BROKER", "upstox")
    assert isinstance(broker.get_broker(), paper.PaperBroker)          # live mode alone is not enough
    from yonexis.data.connectors.upstox import UpstoxConnector
    with pytest.raises(broker.OrdersLocked):
        UpstoxConnector(token="x").place_order("RELIANCE", "BUY", 1)
    with pytest.raises(broker.OrdersLocked):
        UpstoxConnector(token="x").cancel_order("1")


def test_feed_keeps_previous_session_after_midnight(monkeypatch):
    from yonexis.data.connectors import upstox as ux
    feed = ux.UpstoxFeed.__new__(ux.UpstoxFeed)
    feed.symbols, feed.builder, feed.history, feed.interval = ["X"], ux.CandleBuilder(), {}, "5m"
    idx = pd.date_range("2026-10-28 09:15", periods=75, freq="5min")
    feed.history["X"] = pd.DataFrame({"open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5, "volume": 10}, index=idx)
    one = pd.date_range("2026-10-29 09:15", periods=375, freq="1min")
    feed.builder.bars["X"] = {t: [1, 2, 0.5, 1.5, 1] for t in one}
    now = pd.Timestamp("2026-10-30 00:30") - ux.IST_OFFSET     # just after midnight IST
    monkeypatch.setattr(pd.Timestamp, "utcnow", staticmethod(lambda: now.tz_localize("UTC")))
    feed.builder.merge_rest("X", pd.DataFrame(columns=["open", "high", "low", "close", "volume"]))
    feed.roll()
    df = feed.candles("X", "5m")
    assert str(df.index[-1]) == "2026-10-29 15:25:00"         # the 29th survives the day change
    assert df.index.normalize().nunique() == 2 and df.index.is_unique


def test_engine_paper_trades_end_to_end(env, monkeypatch):
    """Simulated feed: strategy calls -> paper fills -> exits -> wallet and signal outcomes updated."""
    cfg, db, paper, broker = env
    monkeypatch.setattr(cfg.settings, "LIVE_CONNECTOR", "simulated")
    monkeypatch.setattr(cfg.settings, "WATCHLIST", ["AAA", "BBB", "CCC"])
    import yonexis.risk.engine as rk
    importlib.reload(rk)
    import yonexis.risk as risk_pkg
    importlib.reload(risk_pkg)
    import yonexis.strategies.loader as loader
    importlib.reload(loader)
    import yonexis.live.engine as le
    importlib.reload(le)
    import inspect
    from yonexis.strategies import first_red_candle_zone as frcz
    db.insert_row(db.strategies, name="first_red_candle_zone", version=1, origin="builtin", status="paper",
                  code=inspect.getsource(frcz), params="{}", spec="{}", review="{}")
    e = le.LiveEngine()
    assert isinstance(e.broker, paper.PaperBroker)
    for _ in range(75 * 2):                       # two simulated sessions
        e.step()
        if e.sim.advance():
            e.emitted = {k for k in e.emitted if pd.Timestamp(k[3]) >= e.sim.current_day}
    trades = db.fetch(db.paper_trades)
    assert trades, "no paper trades were made"
    closed = [t for t in trades if t["status"] == "closed"]
    assert closed and all(t["exit_reason"] in ("target", "stop_loss", "square_off") for t in closed)
    w = e.broker.wallet.get()
    assert w["balance"] == pytest.approx(500000 + sum(t["net_pnl"] for t in closed), abs=0.05)
    taken = [s for s in db.fetch(db.signals) if s["status"] == "closed"]
    assert taken and all(s["outcome_pnl"] is not None for s in taken)
