"""Strategy SDK.

Every strategy (imported, hand-written or AI-written) subclasses `Strategy` and
implements `on_candle`. The same class runs in backtest, paper and live mode.

A strategy only ever sees `ctx`, which exposes data up to and including the
current (closed) candle, so look-ahead is impossible by construction.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import time
from typing import Any, ClassVar

import pandas as pd

BUY = "BUY"
SELL = "SELL"


@dataclass
class Signal:
    side: str                      # BUY or SELL
    stop_loss: float               # absolute price
    target: float | None = None    # absolute price, None = exit at square-off
    reason: str = ""
    tags: dict[str, Any] = field(default_factory=dict)  # extra info, e.g. zone levels
    # entry="market": fill at the next candle's open (decided on a closed candle).
    # entry="stop":   resting stop order at entry_price - fills the moment price touches it (BUY: at/above, SELL: at/below).
    entry: str = "market"
    entry_price: float | None = None
    oco: str | None = None            # stop orders sharing an oco group cancel each other when one fills
    valid_until: str | None = None    # "HH:MM": an unfilled stop order expires after this time

    def __post_init__(self) -> None:
        if self.side not in (BUY, SELL):
            raise ValueError(f"side must be BUY or SELL, got {self.side!r}")
        if self.entry not in ("market", "stop"):
            raise ValueError("entry must be 'market' or 'stop'")
        if self.entry == "stop" and self.entry_price is None:
            raise ValueError("a stop entry needs entry_price")


@dataclass
class Candle:
    ts: pd.Timestamp
    open: float
    high: float
    low: float
    close: float
    volume: float


class Context:
    """Read-only view a strategy gets on each candle."""

    def __init__(self, symbol: str, history: pd.DataFrame, i: int, state: dict, in_position: bool, has_pending: bool = False):
        self.has_pending = has_pending   # resting stop-entry orders exist
        self.symbol = symbol
        self._hist = history
        self._i = i
        self.state = state            # per-strategy, per-symbol scratch space (persists across candles)
        self.in_position = in_position

    @property
    def history(self) -> pd.DataFrame:
        """All candles up to and including the current one."""
        return self._hist.iloc[: self._i + 1]

    @property
    def today(self) -> pd.DataFrame:
        """Today's candles up to and including the current one."""
        h = self.history
        day = h.index[-1].normalize()
        return h[h.index >= day]

    @property
    def now(self) -> pd.Timestamp:
        return self._hist.index[self._i]

    def sma(self, col: str, n: int) -> float:
        return float(self.history[col].tail(n).mean())

    def atr(self, n: int = 14) -> float:
        h = self.history.tail(n + 1)
        prev_close = h["close"].shift(1)
        tr = pd.concat([h["high"] - h["low"], (h["high"] - prev_close).abs(), (h["low"] - prev_close).abs()], axis=1).max(axis=1)
        return float(tr.tail(n).mean())


class Strategy:
    """Base class. Override `params` and `on_candle`."""

    name: ClassVar[str] = "base"
    description: ClassVar[str] = ""
    params: ClassVar[dict[str, Any]] = {}

    session_start: ClassVar[time] = time(9, 15)
    square_off: ClassVar[time] = time(15, 15)

    def __init__(self, **overrides: Any):
        unknown = set(overrides) - set(self.params)
        if unknown:
            raise ValueError(f"unknown params for {self.name}: {sorted(unknown)}")
        self.p = {**self.params, **overrides}

    def on_candle(self, ctx: Context, candle: Candle) -> "Signal | list[Signal] | None":  # pragma: no cover - abstract
        raise NotImplementedError

    def on_entry(self, ctx_state: dict, signal: Signal) -> None:
        """Called when one of this strategy's entries is filled (market or stop)."""

    def on_new_day(self, ctx_state: dict) -> None:
        """Called before the first candle of each day. Default clears state."""
        ctx_state.clear()
