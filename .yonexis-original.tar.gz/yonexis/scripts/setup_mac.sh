#!/usr/bin/env bash
# One-shot local setup for macOS (Apple Silicon or Intel).
#   1. checks Docker Desktop
#   2. installs Ollama natively (uses the Mac GPU) and pulls the coder model
#   3. creates .env with a random admin token
#   4. builds and starts the Docker stack, waits until healthy, opens the dashboard
set -euo pipefail
cd "$(dirname "$0")/.."

say() { printf "\n\033[1;34m==> %s\033[0m\n" "$*"; }

say "Checking Docker"
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker Desktop is not installed. Get it from https://www.docker.com/products/docker-desktop/ and re-run."; exit 1
fi
docker info >/dev/null 2>&1 || { echo "Docker Desktop is installed but not running. Start it and re-run."; exit 1; }

if [ ! -f .env ]; then
  say "Creating .env"
  cp .env.example .env
  TOKEN=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 24)
  sed -i '' "s/^ADMIN_TOKEN=.*/ADMIN_TOKEN=${TOKEN}/" .env
fi
set -a; . ./.env; set +a

say "Setting up Ollama (local open-source LLM)"
if ! command -v ollama >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then
    brew install ollama
  else
    echo "Install Ollama from https://ollama.com/download (or install Homebrew), then re-run."; exit 1
  fi
fi
if ! curl -fs http://localhost:11434/api/tags >/dev/null 2>&1; then
  (brew services start ollama >/dev/null 2>&1) || (nohup ollama serve >/tmp/ollama.log 2>&1 &)
  for i in $(seq 1 30); do curl -fs http://localhost:11434/api/tags >/dev/null 2>&1 && break; sleep 1; done
fi
# Docker Desktop containers reach the Mac's Ollama via host.docker.internal.
if ! curl -fs http://localhost:11434/api/tags | grep -q "${LLM_MODEL}"; then
  say "Pulling ${LLM_MODEL} (several GB, one time)"
  ollama pull "${LLM_MODEL}"
fi

say "Building and starting the stack"
docker compose up -d --build

say "Waiting for the API"
for i in $(seq 1 90); do
  if curl -fs http://localhost:8000/api/health >/dev/null 2>&1; then break; fi; sleep 2
done
curl -fs http://localhost:8000/api/health && echo

say "Loading demo data (simulated, for testing only)"
curl -fs -X POST -H "X-Admin-Token: ${ADMIN_TOKEN}" -H "Content-Type: application/json" \
  "http://localhost:8000/api/data/simulate?start=2024-01-01&end=2025-06-30" -d '["RELIANCE","HDFCBANK","INFY"]' >/dev/null || true

echo
echo "Dashboard:   http://localhost:8000"
echo "Admin token: ${ADMIN_TOKEN}   (also in .env)"
open "http://localhost:8000" 2>/dev/null || true
