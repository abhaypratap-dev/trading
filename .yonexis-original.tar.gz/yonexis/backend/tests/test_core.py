import os
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from yonexis.backtest import BacktestConfig, CostModel, full_evaluation, monte_carlo, run_backtest  # noqa: E402
from yonexis.backtest.parity import compare  # noqa: E402
from yonexis.data.connectors.simulated import simulate  # noqa: E402
from yonexis.data.connectors.upload import parse_candles, parse_trades  # noqa: E402
from yonexis.sandbox import check, run  # noqa: E402
from yonexis.sdk import BUY, Signal, Strategy  # noqa: E402
from yonexis.strategies import FirstRedCandleZone  # noqa: E402

NO_COST = BacktestConfig(costs=CostModel(multiplier=0.0), slippage_bps=0.0, capital_per_trade=10_000)


def candles(rows):
    """rows: list of (HH:MM, o, h, l, c) on 2025-01-06."""
    idx = [pd.Timestamp(f"2025-01-06 {t}") for t, *_ in rows]
    return pd.DataFrame([r[1:] + (1000,) for r in rows], index=idx, columns=["open", "high", "low", "close", "volume"])


class BuyFirstCandle(Strategy):
    name = "buy_first"
    params = {}

    def on_candle(self, ctx, c):
        if ctx.state.get("done"):
            return None
        ctx.state["done"] = True
        return Signal(BUY, stop_loss=c.close - 5, target=c.close + 10)


def test_fills_next_open_and_target():
    df = candles([("09:15", 100, 101, 99, 100), ("09:20", 102, 104, 101, 103), ("09:25", 103, 113, 102, 112)])
    r = run_backtest(BuyFirstCandle, {"X": df}, config=NO_COST)
    t = r.trades.iloc[0]
    assert t.entry == 102                    # next candle open, not signal close
    assert t.exit_reason == "target" and t.exit == 110


def test_stop_first_when_both_hit():
    df = candles([("09:15", 100, 101, 99, 100), ("09:20", 100, 120, 90, 100)])
    t = run_backtest(BuyFirstCandle, {"X": df}, config=NO_COST).trades.iloc[0]
    assert t.exit_reason == "sl"


def test_gap_through_stop_fills_at_open():
    df = candles([("09:15", 100, 101, 99, 100), ("09:20", 101, 101, 100, 100), ("09:25", 90, 91, 89, 90)])
    t = run_backtest(BuyFirstCandle, {"X": df}, config=NO_COST).trades.iloc[0]
    assert t.exit_reason == "sl_gap" and t.exit == 90


def test_square_off():
    df = candles([("09:15", 100, 101, 99, 100), ("09:20", 100, 101, 99, 100), ("15:15", 101, 101, 100, 101)])
    t = run_backtest(BuyFirstCandle, {"X": df}, config=NO_COST).trades.iloc[0]
    assert t.exit_reason == "square_off"


def test_costs_positive_and_reasonable():
    c = CostModel()
    rt = c.round_trip(100_000, 100_500)
    assert 30 < rt < 120          # ~Rs 60-80 for a 1 lakh intraday round trip at a discount broker


def test_zone_strategy_rules():
    df = candles([("09:15", 100, 102, 99.5, 101), ("09:20", 101, 101.5, 100, 100.2),   # first red: zone 100-101.5
                  ("09:25", 100.5, 102, 100.4, 101.8), ("09:30", 101.9, 103, 101.8, 102.5)])
    r = run_backtest(FirstRedCandleZone, {"X": df}, config=NO_COST)
    assert r.signals[0]["side"] == "BUY" and r.signals[0]["ts"].endswith("09:25:00")
    assert r.signals[0]["tags"]["zone_low"] == 100 and r.signals[0]["tags"]["zone_high"] == 101.5


def test_no_lookahead_random_data_has_no_edge():
    data = {s: simulate(s, "2024-01-01", "2024-12-31", seed=i) for i, s in enumerate("ABC")}
    m = run_backtest(FirstRedCandleZone, data, config=BacktestConfig(costs=CostModel(multiplier=0), slippage_bps=0)).metrics
    assert abs(m["net_pnl"]) < 0.08 * 1_000_000 * 3     # no systematic gross edge on a random walk


def test_monte_carlo_shapes():
    t = pd.DataFrame({"net_pnl": [100, -50, 80, -40, 60] * 10})
    mc = monte_carlo(t, n_sims=200)
    assert mc["net_pnl_p5"] <= mc["net_pnl_p50"] <= mc["net_pnl_p95"]


def test_full_evaluation_runs():
    data = {"A": simulate("A", "2024-01-01", "2024-09-30", seed=3)}
    ev = full_evaluation(FirstRedCandleZone, data, {}, param_space={"rr": [1.5, 2.0]}, wf_train_days=60, wf_test_days=30)
    assert ev["verdict"] in ("PASS", "REVIEW", "FAIL") and "checks" in ev


def test_static_check_blocks_bad_code():
    bad = "import subprocess\nfrom yonexis.sdk import Strategy\nclass S(Strategy):\n    name='s'\n    def on_candle(self, ctx, c):\n        return eval('1')\n"
    r = check(bad)
    assert not r["ok"] and any("subprocess" in e for e in r["errors"]) and any("eval" in e for e in r["errors"])


def test_sandbox_runs_strategy():
    code = (Path(__file__).resolve().parents[1] / "yonexis/strategies/first_red_candle_zone.py").read_text()
    r = run(code, {"A": simulate("A", "2024-01-01", "2024-02-28", seed=1)}, {"kind": "quick"})
    assert r["ok"], r
    assert r["result"]["strategy"]["name"] == "first_red_candle_zone"


def test_upload_parse_and_parity():
    raw = pd.DataFrame({"Date": ["2025-01-06 09:15", "2025-01-06 09:20"], "Open": [1, 2], "High": [2, 3], "Low": [0.5, 1.5],
                        "Close": [1.5, 2.5], "Volume": [10, 20], "Ticker": ["RELIANCE.NS", "RELIANCE.NS"]})
    parsed, rep = parse_candles(raw)
    assert list(parsed) == ["RELIANCE"] and rep["symbols"]["RELIANCE"]["interval_minutes"] == 5
    ours = pd.DataFrame([{"symbol": "X", "side": "BUY", "entry_ts": "2025-01-06 09:25", "entry": 100.0, "net_pnl": 10.0}])
    theirs = parse_trades(pd.DataFrame({"Symbol": ["X"], "Type": ["Long"], "Entry Time": ["2025-01-06 09:25"], "Entry Price": [100.1]}))
    rep = compare(ours, theirs)
    assert rep["matched"] == 1 and rep["verdict"] == "PARITY"


def test_api_smoke(tmp_path, monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_LOOP", "false")
    if "yonexis.api.main" in sys.modules:
        pytest.skip("api already imported with other settings")
    os.environ["YONEXIS_DATA_DIR"] = str(tmp_path)
    os.environ["DATABASE_URL"] = f"sqlite:///{tmp_path / 't.db'}"
    os.environ["ADMIN_TOKEN"] = "t"
    import importlib

    import yonexis.config as cfg
    importlib.reload(cfg)
    import yonexis.db as db
    importlib.reload(db)
    from fastapi.testclient import TestClient

    from yonexis.api import main
    importlib.reload(main)
    with TestClient(main.app) as c:
        h = {"X-Admin-Token": "t"}
        assert c.get("/api/health").json()["ok"]
        assert c.get("/api/strategies").status_code == 401
        assert c.post("/api/data/simulate?start=2024-01-01&end=2024-03-31", json=["AAA"], headers=h).status_code == 200
        r = c.post("/api/backtests/quick", json={"strategy": "first_red_candle_zone", "symbols": ["AAA"]}, headers=h)
        assert r.status_code == 200, r.text
        assert r.json()["metrics"]["trades"] > 0
