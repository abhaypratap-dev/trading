"""Deterministic event-driven backtester.

Fill rules (conservative by design):
  * A signal on candle i is filled at the OPEN of candle i+1 (same day), with slippage.
  * Stop loss and target are checked against each candle's high/low.
    If both are touched inside one candle, the STOP is assumed to fill first.
  * Gaps through a level fill at the candle open, not the level.
  * Open positions are squared off at the strategy's square-off time.
Every number in the platform comes from here, never from an LLM.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from yonexis.sdk import BUY, Candle, Context, Signal, Strategy

from .costs import CostModel
from .metrics import compute_metrics

TRADE_COLUMNS = [
    "symbol", "side", "signal_ts", "entry_ts", "entry", "exit_ts", "exit", "qty",
    "stop_loss", "target", "exit_reason", "gross_pnl", "costs", "net_pnl", "ret_pct", "reason", "tags",
]


@dataclass
class BacktestConfig:
    capital_per_trade: float = 100_000.0
    slippage_bps: float = 2.0            # 1 bps = 0.01%
    fill: str = "next_open"              # "next_open" or "close"
    costs: CostModel = field(default_factory=CostModel)
    starting_capital: float = 1_000_000.0


@dataclass
class BacktestResult:
    trades: pd.DataFrame
    daily: pd.DataFrame
    metrics: dict[str, Any]
    signals: list[dict]

    def to_dict(self, include_trades: bool = True) -> dict:
        out = {"metrics": self.metrics, "n_signals": len(self.signals)}
        if include_trades:
            t = self.trades.copy()
            for col in ("signal_ts", "entry_ts", "exit_ts"):
                if col in t:
                    t[col] = t[col].astype(str)
            out["trades"] = t.to_dict(orient="records")
            d = self.daily.reset_index()
            d["date"] = d["date"].astype(str)
            out["daily"] = d.to_dict(orient="records")
        return out


def _slip(price: float, side: str, bps: float, entering: bool) -> float:
    """Move price against us."""
    adverse_up = (side == BUY) == entering   # buying -> pay more; selling -> receive less
    k = bps / 10_000
    return price * (1 + k) if adverse_up else price * (1 - k)


def normalize_candles(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.lower() for c in df.columns]
    if "ts" in df.columns:
        df = df.set_index("ts")
    df.index = pd.to_datetime(df.index)
    if df.index.tz is not None:
        df.index = df.index.tz_convert("Asia/Kolkata").tz_localize(None)
    df = df[~df.index.duplicated(keep="last")].sort_index()
    if "volume" not in df:
        df["volume"] = 0.0
    return df[["open", "high", "low", "close", "volume"]].astype(float)


def run_backtest(
    strategy_cls: type[Strategy],
    data: dict[str, pd.DataFrame],
    params: dict | None = None,
    config: BacktestConfig | None = None,
) -> BacktestResult:
    cfg = config or BacktestConfig()
    trades: list[dict] = []
    signals: list[dict] = []

    for symbol, raw in data.items():
        df = normalize_candles(raw)
        if df.empty:
            continue
        strat = strategy_cls(**(params or {}))
        state: dict = {}
        pos: dict | None = None
        pending: tuple[Signal, pd.Timestamp] | None = None
        idx = df.index
        o, h, lo, c, v = (df[k].to_numpy() for k in ("open", "high", "low", "close", "volume"))
        prev_day = None

        def close_pos(exit_px: float, ts, why: str) -> None:
            nonlocal pos
            p = pos
            d = 1 if p["side"] == BUY else -1
            gross = (exit_px - p["entry"]) * p["qty"] * d
            buy_v = p["entry"] * p["qty"] if d == 1 else exit_px * p["qty"]
            sell_v = exit_px * p["qty"] if d == 1 else p["entry"] * p["qty"]
            cost = cfg.costs.round_trip(buy_v, sell_v)
            trades.append({
                **{k: p[k] for k in ("symbol", "side", "signal_ts", "entry_ts", "entry", "qty", "stop_loss", "target", "reason", "tags")},
                "exit_ts": ts, "exit": round(exit_px, 4), "exit_reason": why,
                "gross_pnl": round(gross, 2), "costs": round(cost, 2), "net_pnl": round(gross - cost, 2),
                "ret_pct": round((gross - cost) / (p["entry"] * p["qty"]) * 100, 4),
            })
            pos = None

        def open_pos(sig: Signal, sig_ts, px: float, ts) -> None:
            nonlocal pos
            fill = _slip(px, sig.side, cfg.slippage_bps, entering=True)
            qty = math.floor(cfg.capital_per_trade / fill)
            if qty <= 0:
                return
            # Reject fills that already breach the stop (gap through SL).
            if (sig.side == BUY and fill <= sig.stop_loss) or (sig.side != BUY and fill >= sig.stop_loss):
                return
            pos = {"symbol": symbol, "side": sig.side, "signal_ts": sig_ts, "entry_ts": ts, "entry": round(fill, 4),
                   "qty": qty, "stop_loss": sig.stop_loss, "target": sig.target, "reason": sig.reason, "tags": sig.tags}

        for i in range(len(df)):
            ts = idx[i]
            day = ts.date()
            if day != prev_day:
                # Safety: never carry an intraday position overnight.
                if pos is not None:
                    close_pos(_slip(c[i - 1], pos["side"], cfg.slippage_bps, False), idx[i - 1], "eod")
                pending = None
                strat.on_new_day(state)
                prev_day = day

            # 1) fill pending entry at this candle's open
            if pending is not None and pos is None:
                sig, sig_ts = pending
                pending = None
                if ts.time() < strat.square_off:
                    open_pos(sig, sig_ts, o[i], ts)

            # 2) exits inside this candle
            if pos is not None:
                is_long = pos["side"] == BUY
                sl, tgt = pos["stop_loss"], pos["target"]
                if is_long:
                    if o[i] <= sl:
                        close_pos(_slip(o[i], BUY, cfg.slippage_bps, False), ts, "sl_gap")
                    elif lo[i] <= sl:
                        close_pos(_slip(sl, BUY, cfg.slippage_bps, False), ts, "sl")
                    elif tgt is not None and o[i] >= tgt:
                        close_pos(o[i], ts, "target_gap")
                    elif tgt is not None and h[i] >= tgt:
                        close_pos(tgt, ts, "target")
                else:
                    if o[i] >= sl:
                        close_pos(_slip(o[i], "SELL", cfg.slippage_bps, False), ts, "sl_gap")
                    elif h[i] >= sl:
                        close_pos(_slip(sl, "SELL", cfg.slippage_bps, False), ts, "sl")
                    elif tgt is not None and o[i] <= tgt:
                        close_pos(o[i], ts, "target_gap")
                    elif tgt is not None and lo[i] <= tgt:
                        close_pos(tgt, ts, "target")

            # 3) square off
            if pos is not None and ts.time() >= strat.square_off:
                close_pos(_slip(c[i], pos["side"], cfg.slippage_bps, False), ts, "square_off")

            # 4) strategy decision on the closed candle
            ctx = Context(symbol, df, i, state, in_position=pos is not None or pending is not None)
            sig = strat.on_candle(ctx, Candle(ts, o[i], h[i], lo[i], c[i], v[i]))
            if sig is not None and pos is None and pending is None and ts.time() < strat.square_off:
                signals.append({"symbol": symbol, "ts": str(ts), "side": sig.side, "close": c[i],
                                "stop_loss": sig.stop_loss, "target": sig.target, "reason": sig.reason, "tags": sig.tags})
                if cfg.fill == "close":
                    open_pos(sig, ts, c[i], ts)
                else:
                    pending = (sig, ts)

        if pos is not None:
            close_pos(_slip(c[-1], pos["side"], cfg.slippage_bps, False), idx[-1], "end_of_data")

    tdf = pd.DataFrame(trades, columns=TRADE_COLUMNS)
    daily = daily_pnl(tdf, cfg.starting_capital)
    return BacktestResult(tdf, daily, compute_metrics(tdf, daily), signals)


def daily_pnl(trades: pd.DataFrame, starting_capital: float) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=["net_pnl", "equity", "ret"], index=pd.Index([], name="date"))
    t = trades.copy()
    t["date"] = pd.to_datetime(t["exit_ts"]).dt.normalize()
    d = t.groupby("date")["net_pnl"].sum().to_frame()
    d["equity"] = starting_capital + d["net_pnl"].cumsum()
    d["ret"] = d["net_pnl"] / d["equity"].shift(1).fillna(starting_capital)
    return d
