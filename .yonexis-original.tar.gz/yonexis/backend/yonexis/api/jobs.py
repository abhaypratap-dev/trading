"""In-process background jobs for long tasks (agent builds, full evaluations, training)."""
from __future__ import annotations

import threading
import time
import traceback
import uuid
from typing import Any, Callable

JOBS: dict[str, dict[str, Any]] = {}


def submit(kind: str, fn: Callable[[Callable[[str, dict], None]], Any]) -> str:
    jid = uuid.uuid4().hex[:12]
    JOBS[jid] = {"id": jid, "kind": kind, "status": "running", "stage": "queued", "log": [], "started": time.time(), "result": None}

    def progress(stage: str, info: dict) -> None:
        JOBS[jid]["stage"] = stage
        JOBS[jid]["log"].append({"t": round(time.time() - JOBS[jid]["started"], 1), "stage": stage,
                                 **{k: v for k, v in info.items() if k != "code"}})

    def target():
        try:
            JOBS[jid]["result"] = fn(progress)
            JOBS[jid]["status"] = "done"
        except Exception as e:
            JOBS[jid]["status"] = "error"
            JOBS[jid]["error"] = f"{type(e).__name__}: {e}"
            JOBS[jid]["trace"] = traceback.format_exc()[-3000:]
        JOBS[jid]["elapsed"] = round(time.time() - JOBS[jid]["started"], 1)

    threading.Thread(target=target, daemon=True).start()
    return jid


def get(jid: str) -> dict | None:
    return JOBS.get(jid)
