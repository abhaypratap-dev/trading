"""YONEXIS API: dashboards, data, strategies, backtests, agents, live signals, feedback, models, risk."""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import pandas as pd
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from yonexis import db, feedback
from yonexis.agents import llm, pipeline
from yonexis.backtest import BacktestConfig, CostModel, full_evaluation, run_backtest
from yonexis.backtest.parity import compare
from yonexis.config import settings
from yonexis.data.connectors import AVAILABLE, get_connector
from yonexis.data.connectors.simulated import simulate
from yonexis.data.connectors.upload import interval_label, parse_candles, parse_trades, preview, read_any
from yonexis.live import engine as live
from yonexis.ml import TrainedModel, train_imitation, train_meta
from yonexis.risk import risk
from yonexis.sandbox import check as static_check
from yonexis.sandbox import run as sandbox_run
from yonexis.strategies import REGISTRY
from yonexis.strategies.loader import latest_versions

from . import jobs

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
WEB_DIR = Path(__file__).resolve().parents[3] / "web"


def seed_builtins() -> None:
    have = latest_versions()
    for name, cls in REGISTRY.items():
        if name not in have:
            import inspect
            code = inspect.getsource(inspect.getmodule(cls))
            db.insert_row(db.strategies, name=name, version=1, origin="builtin", status="paper", code=code,
                          params=db.j({}), spec=db.j({"summary": cls.description}), review=db.j({"static_check": static_check(code)}))


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init()
    seed_builtins()
    task = None
    if settings.ENABLE_LIVE_LOOP:
        live.engine = live.LiveEngine()
        task = asyncio.create_task(live.engine.run())
    yield
    if live.engine:
        live.engine.stop()
    if task:
        task.cancel()


app = FastAPI(title="YONEXIS AI Trading Platform", version="0.1.0", lifespan=lifespan)


def admin(x_admin_token: str | None = Header(default=None)) -> None:
    if settings.ADMIN_TOKEN and x_admin_token != settings.ADMIN_TOKEN:
        raise HTTPException(401, "missing or wrong X-Admin-Token")


A = [Depends(admin)]


# ====================================================================== helpers

def load_data(symbols: list[str], interval: str, start: str | None, end: str | None, source: str = "db") -> dict[str, pd.DataFrame]:
    out = {}
    for s in symbols:
        if source == "simulated":
            df = simulate(s, start or "2024-01-01", end or "2025-06-30", int(interval.rstrip("m")) if interval.endswith("m") else 5)
        else:
            df = db.load_candles(s, interval, start, end)
        if not df.empty:
            out[s.upper()] = df
    if not out:
        raise HTTPException(400, f"no {interval} candles found for {symbols} in {start}..{end}. Load data first (Data tab).")
    return out


def strategy_code(name: str, version: int | None = None) -> dict:
    rows = db.fetch(db.strategies, db.strategies.c.name == name, order=db.strategies.c.version)
    if version is not None:
        rows = [r for r in rows if r["version"] == version]
    if not rows:
        raise HTTPException(404, f"strategy {name} not found")
    return rows[-1]


def save_strategy(name: str, code: str, origin: str, spec: dict | None = None, review: dict | None = None,
                  params: dict | None = None) -> dict:
    prev = db.fetch(db.strategies, db.strategies.c.name == name, order=db.strategies.c.version)
    version = (prev[-1]["version"] + 1) if prev else 1
    sid = db.insert_row(db.strategies, name=name, version=version, origin=origin, status="candidate", code=code,
                        spec=db.j(spec or {}), review=db.j(review or {}), params=db.j(params or {}))
    db.log("admin", "strategy_saved", {"name": name, "version": version, "origin": origin})
    return {"id": sid, "name": name, "version": version}


def config_from(body: dict | None) -> dict:
    body = body or {}
    return {"capital_per_trade": body.get("capital_per_trade", 100000), "slippage_bps": body.get("slippage_bps", 2.0),
            "fill": body.get("fill", "next_open"), "costs": body.get("costs", {})}


def _cfg(c: dict) -> BacktestConfig:
    c = dict(c)
    return BacktestConfig(costs=CostModel(**c.pop("costs", {})), **c)


# ====================================================================== health / meta

@app.get("/api/health")
def health():
    return {"ok": True, "db": settings.DATABASE_URL.split(":")[0], "llm": llm.health(), "connector": settings.LIVE_CONNECTOR,
            "trading_mode": settings.TRADING_MODE, "live_engine": bool(live.engine and live.engine.running),
            "live_error": live.engine.last_error if live.engine else None}


@app.get("/api/connectors", dependencies=A)
def connectors():
    return AVAILABLE


# ====================================================================== data

class FetchBody(BaseModel):
    symbols: list[str]
    source: str = "yahoo"
    interval: str = "5m"
    start: str
    end: str


@app.post("/api/data/fetch", dependencies=A)
def data_fetch(b: FetchBody):
    conn = get_connector(b.source)
    out = {}
    for s in b.symbols:
        try:
            df = conn.fetch_history(s, b.start, b.end, b.interval)
            out[s] = db.save_candles(s, df, b.interval, b.source)
        except Exception as e:
            out[s] = f"error: {e}"
    total = sum(v for v in out.values() if isinstance(v, int))
    db.insert_row(db.datasets, name=f"{b.source} {b.interval} {b.start}..{b.end}", kind="candles", source=b.source,
                  rows=total, symbols=db.j(b.symbols), start=b.start, end=b.end, meta=db.j(out))
    return {"saved_rows": out}


@app.post("/api/data/upload/preview", dependencies=A)
async def upload_preview(file: UploadFile = File(...)):
    return preview(file.filename, await file.read())


@app.post("/api/data/upload", dependencies=A)
async def upload(file: UploadFile = File(...), kind: str = Form("candles"), mapping: str = Form("{}"),
                 symbol: str = Form(""), interval: str = Form(""), date_col: str = Form(""), time_col: str = Form("")):
    content = await file.read()
    (settings.uploads_dir / file.filename).write_bytes(content)
    df = read_any(file.filename, content)
    m = db.uj(mapping, {}) or {}
    if kind == "trades":
        t = parse_trades(df, m)
        did = db.insert_row(db.datasets, name=file.filename, kind="trades", source="upload", rows=len(t),
                            symbols=db.j(sorted(t["symbol"].unique().tolist())), start=str(t["entry_ts"].min()),
                            end=str(t["entry_ts"].max()), meta=db.j({"file": file.filename, "mapping": m}))
        return {"dataset_id": did, "rows": len(t), "sample": t.head(5).astype(str).to_dict("records")}
    parsed, report = parse_candles(df, m, symbol or None, date_col or None, time_col or None)
    saved = {}
    for s, g in parsed.items():
        iv = interval or interval_label(report["symbols"][s]["interval_minutes"])
        saved[s] = {"interval": iv, "rows": db.save_candles(s, g, iv, "upload")}
    did = db.insert_row(db.datasets, name=file.filename, kind="candles", source="upload", rows=report["output_rows"],
                        symbols=db.j(sorted(parsed)), start=min((v["start"] for v in report.get("symbols", {}).values()), default=""),
                        end=max((v["end"] for v in report.get("symbols", {}).values()), default=""), meta=db.j(report))
    db.log("admin", "upload", {"file": file.filename, "dataset_id": did})
    return {"dataset_id": did, "report": report, "saved": saved}


@app.post("/api/data/simulate", dependencies=A)
def data_simulate(symbols: list[str], start: str = "2024-01-01", end: str = "2025-06-30"):
    out = {s: db.save_candles(s, simulate(s, start, end), "5m", "simulated") for s in symbols}
    db.insert_row(db.datasets, name=f"simulated {start}..{end}", kind="candles", source="simulated", rows=sum(out.values()),
                  symbols=db.j(symbols), start=start, end=end, meta=db.j({}))
    return out


@app.get("/api/data/inventory", dependencies=A)
def inventory():
    return {"candles": db.candle_inventory(), "datasets": db.fetch(db.datasets, order=db.datasets.c.id.desc(), limit=100)}


@app.get("/api/candles", dependencies=A)
def get_candles(symbol: str, interval: str = "5m", start: str | None = None, end: str | None = None, live_view: bool = False):
    if live_view and live.engine and symbol.upper() in live.engine.cache:
        df = live.engine.cache[symbol.upper()]
        df = df[df.index >= df.index[-1].normalize()]          # today's session only
    else:
        df = db.load_candles(symbol, interval, start, end)
    if df.empty:
        return []
    d = df.reset_index()
    d["ts"] = d["ts"].astype(str)
    return d.to_dict("records")


# ====================================================================== strategies

@app.get("/api/strategies", dependencies=A)
def list_strategies():
    rows = db.fetch(db.strategies, order=db.strategies.c.id)
    for r in rows:
        r["spec"], r["review"], r["params"] = db.uj(r["spec"], {}), db.uj(r["review"], {}), db.uj(r["params"], {})
    return rows


class CodeBody(BaseModel):
    name: str | None = None
    code: str
    origin: str = "upload"
    spec: dict | None = None


@app.post("/api/strategies", dependencies=A)
def upload_strategy(b: CodeBody):
    sc = static_check(b.code)
    if not sc["ok"]:
        raise HTTPException(400, {"static_check": sc})
    d = sandbox_run(b.code, {"SIM": simulate("SIM", "2024-01-01", "2024-02-28")}, {"kind": "describe"}, timeout=60)
    if not d.get("ok"):
        raise HTTPException(400, {"error": d.get("error"), "trace": d.get("trace")})
    name = b.name or d["result"]["strategy"]["name"]
    return {**save_strategy(name, b.code, b.origin, b.spec, {"static_check": sc}), "static_check": sc,
            "described": d["result"]["strategy"]}


class StatusBody(BaseModel):
    status: str
    params: dict | None = None


@app.post("/api/strategies/{name}/{version}/status", dependencies=A)
def set_status(name: str, version: int, b: StatusBody):
    allowed = ("candidate", "approved", "paper", "live_small", "live", "retired")
    if b.status not in allowed:
        raise HTTPException(400, f"status must be one of {allowed}")
    row = strategy_code(name, version)
    if b.status in ("live_small", "live") and settings.TRADING_MODE != "live":
        raise HTTPException(400, "TRADING_MODE is not 'live'; strategies can run in paper mode only")
    upd = {"status": b.status}
    if b.params is not None:
        upd["params"] = db.j(b.params)
    db.update_row(db.strategies, row["id"], **upd)
    db.log("admin", "strategy_status", {"name": name, "version": version, "status": b.status})
    return {"ok": True}


# ====================================================================== backtests

class BacktestBody(BaseModel):
    strategy: str
    version: int | None = None
    symbols: list[str]
    interval: str = "5m"
    start: str | None = None
    end: str | None = None
    source: str = "db"
    params: dict = Field(default_factory=dict)
    config: dict = Field(default_factory=dict)
    param_space: dict | None = None
    baseline_net_pnl: float | None = None


@app.post("/api/backtests/quick", dependencies=A)
def quick_backtest(b: BacktestBody):
    row = strategy_code(b.strategy, b.version)
    data = load_data(b.symbols, b.interval, b.start, b.end, b.source)
    r = sandbox_run(row["code"], data, {"kind": "quick", "params": b.params, "config": config_from(b.config)})
    if not r.get("ok"):
        raise HTTPException(400, {"error": r.get("error"), "trace": r.get("trace")})
    res = r["result"]
    bid = db.insert_row(db.backtests, strategy=b.strategy, strategy_version=row["version"], kind="quick", params=db.j(b.params),
                        symbols=db.j(b.symbols), start=b.start, end=b.end,
                        result=db.j({"metrics": res["metrics"], "trades": res["trades"][:3000]}))
    return {"id": bid, **res}


@app.post("/api/backtests/full", dependencies=A)
def full_backtest(b: BacktestBody):
    row = strategy_code(b.strategy, b.version)
    data = load_data(b.symbols, b.interval, b.start, b.end, b.source)

    def work(progress):
        progress("full_evaluation", {})
        r = sandbox_run(row["code"], data, {"kind": "full", "params": b.params, "config": config_from(b.config),
                                            "param_space": b.param_space, "baseline_net_pnl": b.baseline_net_pnl}, timeout=3600)
        if not r.get("ok"):
            raise RuntimeError(r.get("error"))
        ev = r["result"]
        progress("critic", {})
        ev["critic"] = pipeline.critic(ev)
        ev["report"] = pipeline.report(ev)
        ev["id"] = db.insert_row(db.backtests, strategy=b.strategy, strategy_version=row["version"], kind="full",
                                 params=db.j(b.params), symbols=db.j(b.symbols), start=b.start, end=b.end, result=db.j(ev))
        return ev

    return {"job_id": jobs.submit("full_backtest", work)}


@app.get("/api/backtests", dependencies=A)
def list_backtests(limit: int = 50):
    rows = db.fetch(db.backtests, order=db.backtests.c.id.desc(), limit=limit)
    for r in rows:
        res = db.uj(r.pop("result"), {})
        r["summary"] = res.get("metrics") or {"verdict": res.get("verdict"), "score": res.get("score"), **(res.get("development") or {})}
        r["summary"] = {k: r["summary"].get(k) for k in ("verdict", "score", "trades", "net_pnl", "win_rate", "profit_factor", "sharpe", "max_drawdown_pct")}
    return rows


@app.get("/api/backtests/{bid}", dependencies=A)
def get_backtest(bid: int):
    rows = db.fetch(db.backtests, db.backtests.c.id == bid)
    if not rows:
        raise HTTPException(404)
    r = rows[0]
    r["result"] = db.uj(r["result"], {})
    return r


# ====================================================================== parity (import admin scripts)

class ConvertBody(BaseModel):
    source: str
    language: str = "auto"
    notes: str = ""
    name: str | None = None


@app.post("/api/import/convert", dependencies=A)
def convert(b: ConvertBody):
    def work(progress):
        progress("converting", {})
        code = pipeline.convert_script(b.source, b.language, b.notes)
        progress("review", {})
        rv = pipeline.review(code, {"original_language": b.language, "notes": b.notes})
        for i in range(2):
            problems = rv["static_check"]["errors"] + [f"{x.get('problem')} -> {x.get('fix')}" for x in rv.get("issues", []) if x.get("severity") == "high"]
            if not problems:
                break
            progress("fixing", {"round": i, "problems": problems[:5]})
            code = pipeline.fix(code, problems)
            rv = pipeline.review(code, {"original_language": b.language})
        saved = None
        if rv["static_check"]["ok"]:
            d = sandbox_run(code, {"SIM": simulate("SIM", "2024-01-01", "2024-02-28")}, {"kind": "describe"}, timeout=60)
            if d.get("ok"):
                saved = save_strategy(b.name or d["result"]["strategy"]["name"], code, "import",
                                      {"original_language": b.language, "original": b.source[:20000]}, rv)
        return {"code": code, "review": rv, "saved": saved}

    return {"job_id": jobs.submit("convert", work)}


@app.post("/api/import/parity", dependencies=A)
async def parity(strategy: str = Form(...), version: int | None = Form(None), interval: str = Form("5m"),
                 params: str = Form("{}"), config: str = Form("{}"), mapping: str = Form("{}"),
                 time_tolerance_min: int = Form(10), file: UploadFile = File(...)):
    theirs = parse_trades(read_any(file.filename, await file.read()), db.uj(mapping, {}))
    if theirs.empty:
        raise HTTPException(400, "no trades parsed from the file; check the column mapping")
    syms = sorted(s for s in theirs["symbol"].unique() if s != "UNKNOWN")
    start, end = str(theirs["entry_ts"].min().date()), str(theirs["entry_ts"].max().date())
    data = load_data(syms, interval, start, end)
    row = strategy_code(strategy, version)
    r = sandbox_run(row["code"], data, {"kind": "quick", "params": db.uj(params, {}), "config": config_from(db.uj(config, {}))})
    if not r.get("ok"):
        raise HTTPException(400, {"error": r.get("error"), "trace": r.get("trace")})
    ours = pd.DataFrame(r["result"]["trades"])
    rep = compare(ours, theirs, time_tolerance_min)
    rep["our_metrics"] = r["result"]["metrics"]
    rep["id"] = db.insert_row(db.backtests, strategy=strategy, strategy_version=row["version"], kind="parity", params=params,
                              symbols=db.j(syms), start=start, end=end, result=db.j(rep))
    return rep


# ====================================================================== AI builder

class PromptBody(BaseModel):
    prompt: str
    context: str = ""


@app.post("/api/agents/spec", dependencies=A)
def agent_spec(b: PromptBody):
    try:
        return pipeline.spec_from_prompt(b.prompt, b.context)
    except llm.LLMError as e:
        raise HTTPException(503, str(e))


class BuildBody(BaseModel):
    spec: dict
    symbols: list[str]
    interval: str = "5m"
    start: str | None = None
    end: str | None = None
    source: str = "db"
    config: dict = Field(default_factory=dict)
    baseline_net_pnl: float | None = None
    save: bool = True


@app.post("/api/agents/build", dependencies=A)
def agent_build(b: BuildBody):
    data = load_data(b.symbols, b.interval, b.start, b.end, b.source)
    n_prev = len(db.fetch(db.backtests))

    def work(progress):
        out = pipeline.build_strategy(b.spec, data, baseline_net_pnl=b.baseline_net_pnl, n_trials_so_far=max(1, n_prev),
                                      progress=progress, config=config_from(b.config))
        if out.get("ok") and b.save:
            out["saved"] = save_strategy(out["name"], out["code"], "ai", b.spec, out["review"])
            out["backtest_id"] = db.insert_row(db.backtests, strategy=out["name"], strategy_version=out["saved"]["version"],
                                               kind="full", params=db.j({}), symbols=db.j(b.symbols), start=b.start, end=b.end,
                                               result=db.j({**out["evaluation"], "critic": out["critic"], "report": out["report"]}))
        return out

    return {"job_id": jobs.submit("agent_build", work)}


@app.get("/api/jobs/{jid}", dependencies=A)
def job(jid: str):
    j = jobs.get(jid)
    if not j:
        raise HTTPException(404)
    return j


# ====================================================================== live

@app.get("/api/live/status", dependencies=A)
def live_status():
    e = live.engine
    if not e:
        return {"running": False}
    return {"running": e.running, "connector": e.connector_name, "rows": e.status, "error": e.last_error,
            "sim_day": str(e.sim.current_day.date()) if e.sim else None, "risk": risk.snapshot()}


@app.get("/api/signals", dependencies=A)
def list_signals(limit: int = 200):
    rows = db.fetch(db.signals, order=db.signals.c.id.desc(), limit=limit)
    fb = {}
    for f in db.fetch(db.feedback, order=db.feedback.c.id):
        fb[f["signal_id"]] = {"action": f["action"], "remark": f["remark"]}
    for r in rows:
        r.pop("features", None)
        r["tags"] = db.uj(r["tags"], {})
        r["feedback"] = fb.get(r["id"])
    return rows


@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    if settings.ADMIN_TOKEN and ws.query_params.get("token") != settings.ADMIN_TOKEN:
        await ws.close(code=4401)
        return
    await ws.accept()
    q: asyncio.Queue = asyncio.Queue(maxsize=200)
    if live.engine:
        live.engine.subscribers.add(q)
    try:
        while True:
            await ws.send_text(await q.get())
    except WebSocketDisconnect:
        pass
    finally:
        if live.engine:
            live.engine.subscribers.discard(q)


# ====================================================================== feedback

class FeedbackBody(BaseModel):
    action: str
    remark: str = ""
    new_sl: float | None = None
    new_target: float | None = None


@app.post("/api/signals/{sid}/feedback", dependencies=A)
def give_feedback(sid: int, b: FeedbackBody):
    try:
        fid = feedback.record(sid, b.action, b.remark, b.new_sl, b.new_target)
    except (KeyError, ValueError) as e:
        raise HTTPException(400, str(e))
    if b.remark.strip():
        tags = pipeline.tag_remarks([{"id": fid, "remark": b.remark}])
        db.update_row(db.feedback, fid, reasons=db.j(tags.get(fid, [])))
    return {"id": fid}


@app.get("/api/feedback/scoreboard", dependencies=A)
def scoreboard():
    return feedback.scoreboard()


@app.post("/api/feedback/suggestions", dependencies=A)
def suggestions():
    return {"suggestions": pipeline.suggest_from_feedback(feedback.scoreboard())}


# ====================================================================== models

class TrainMetaBody(BaseModel):
    strategy: str
    version: int | None = None
    symbols: list[str]
    interval: str = "5m"
    start: str | None = None
    end: str | None = None
    source: str = "db"
    params: dict = Field(default_factory=dict)


@app.post("/api/models/train-meta", dependencies=A)
def train_meta_ep(b: TrainMetaBody):
    row = strategy_code(b.strategy, b.version)
    data = load_data(b.symbols, b.interval, b.start, b.end, b.source)

    def work(progress):
        from yonexis.strategies.loader import load_code
        progress("backtest", {})
        cls = load_code(row["code"]) if row["origin"] != "builtin" else REGISTRY[row["name"]]
        res = run_backtest(cls, data, b.params)
        progress("training", {"trades": len(res.trades)})
        m = train_meta(res, data)
        m.meta.update({"strategy": b.strategy, "strategy_version": row["version"], "symbols": b.symbols})
        p = m.save(settings.models_dir)
        mid = db.insert_row(db.models, kind="meta", version=m.version, strategy=b.strategy, path=str(p), metrics=db.j(m.metrics),
                            status="shadow")
        return {"model_id": mid, "version": m.version, "metrics": m.metrics}

    return {"job_id": jobs.submit("train_meta", work)}


@app.post("/api/models/train-imitation", dependencies=A)
def train_imitation_ep(strategy: str | None = None):
    rows = feedback.rows_with_outcomes()
    rows = [r for r in rows if strategy in (None, r["strategy"])]
    try:
        m = train_imitation([{"features": r["features"], "action": r["action"], "ts": r["signal_ts"]} for r in rows])
    except ValueError as e:
        raise HTTPException(400, str(e))
    p = m.save(settings.models_dir)
    mid = db.insert_row(db.models, kind="imitation", version=m.version, strategy=strategy, path=str(p),
                        metrics=db.j(m.metrics), status="shadow")
    return {"model_id": mid, "metrics": m.metrics}


@app.get("/api/models", dependencies=A)
def list_models():
    rows = db.fetch(db.models, order=db.models.c.id.desc())
    for r in rows:
        r["metrics"] = db.uj(r["metrics"], {})
    return rows


@app.post("/api/models/{mid}/promote", dependencies=A)
def promote(mid: int):
    rows = db.fetch(db.models, db.models.c.id == mid)
    if not rows:
        raise HTTPException(404)
    m = rows[0]
    for other in db.fetch(db.models):
        if other["kind"] == m["kind"] and other["strategy"] == m["strategy"] and other["status"] == "champion":
            db.update_row(db.models, other["id"], status="retired")
    db.update_row(db.models, mid, status="champion")
    db.log("admin", "model_promoted", {"id": mid})
    return {"ok": True}


# ====================================================================== risk

@app.get("/api/risk", dependencies=A)
def get_risk():
    return risk.snapshot()


@app.post("/api/risk/kill", dependencies=A)
def kill(reason: str = "manual kill switch"):
    risk.kill(reason)
    db.log("admin", "kill_switch", {"reason": reason})
    return risk.snapshot()


@app.post("/api/risk/reset", dependencies=A)
def reset():
    risk.reset_kill()
    db.log("admin", "kill_reset", {})
    return risk.snapshot()


@app.get("/api/audit", dependencies=A)
def audit(limit: int = 200):
    return db.fetch(db.audit, order=db.audit.c.id.desc(), limit=limit)


# ====================================================================== web

if WEB_DIR.exists():
    app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")

    @app.get("/")
    def index():
        return FileResponse(WEB_DIR / "index.html")


@app.exception_handler(Exception)
async def on_error(request, exc):  # pragma: no cover
    logging.exception("unhandled")
    return JSONResponse(status_code=500, content={"detail": f"{type(exc).__name__}: {exc}"})


def _unused(*_: Any) -> None:  # keep imports referenced for linters
    _ = (full_evaluation, TrainedModel)
