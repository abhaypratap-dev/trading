"""Load strategies stored in the database (uploaded, imported or AI-built).

Only code that passed the static check AND was approved by the admin is loaded
in-process for the live loop. Everything else runs in the sandbox.
"""
from __future__ import annotations

import types

from yonexis import db
from yonexis.sandbox import check
from yonexis.sdk import Strategy

LIVE_STATUSES = ("paper", "live_small", "live")


def load_code(code: str) -> type[Strategy]:
    sc = check(code)
    if not sc["ok"]:
        raise ValueError(f"static check failed: {sc['errors']}")
    mod = types.ModuleType("yonexis_user_strategy")
    exec(compile(code, "<strategy>", "exec"), mod.__dict__)  # noqa: S102 - admin-approved, statically checked code only
    classes = [v for v in vars(mod).values() if isinstance(v, type) and issubclass(v, Strategy) and v is not Strategy]
    if not classes:
        raise ValueError("no Strategy subclass")
    return classes[-1]


def latest_versions() -> dict[str, dict]:
    rows = db.fetch(db.strategies, order=db.strategies.c.version)
    out: dict[str, dict] = {}
    for r in rows:
        out[r["name"]] = r
    return out


def active_live() -> list[tuple[dict, type[Strategy]]]:
    out = []
    for r in latest_versions().values():
        if r["status"] in LIVE_STATUSES:
            try:
                out.append((r, load_code(r["code"])))
            except Exception:
                continue
    return out
