"""Built-in strategy registry. Uploaded/AI-written strategies are registered at runtime."""
from __future__ import annotations

from yonexis.sdk import Strategy

from .first_red_candle_zone import FirstRedCandleZone

REGISTRY: dict[str, type[Strategy]] = {
    FirstRedCandleZone.name: FirstRedCandleZone,
}


def register(cls: type[Strategy]) -> None:
    REGISTRY[cls.name] = cls


def get(name: str) -> type[Strategy]:
    if name not in REGISTRY:
        raise KeyError(f"unknown strategy {name!r}; known: {sorted(REGISTRY)}")
    return REGISTRY[name]
