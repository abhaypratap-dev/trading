"""First Red Candle Zone (the YONEXIS dashboard strategy).

The first red candle of the session (from 09:15 on the chosen timeframe)
defines a zone [low, high].
  - A candle CLOSE above the zone high  -> BUY
  - A candle CLOSE below the zone low   -> SELL
Stop loss sits on the opposite side of the zone (plus a buffer); target is a
multiple of risk. One trade per day by default.
"""
from __future__ import annotations

from datetime import time

from yonexis.sdk import BUY, SELL, Candle, Context, Signal, Strategy


class FirstRedCandleZone(Strategy):
    name = "first_red_candle_zone"
    description = "First red candle of the session defines a zone; close above = BUY, close below = SELL."
    params = {
        "sl_mode": "opposite",       # "opposite" = other edge of zone, "mid" = zone middle
        "sl_buffer_pct": 0.05,       # extra % beyond the SL level
        "rr": 2.0,                   # target = rr * risk
        "max_trades_per_day": 1,
        "min_zone_pct": 0.05,        # skip zones narrower than this % of price
        "max_zone_pct": 1.5,         # skip zones wider than this % of price
        "entry_cutoff": "14:30",     # no new entries after this time
        "allow_short": True,
        "min_volume_ratio": 0.0,     # breakout candle volume / avg volume of today's earlier candles
    }

    def on_candle(self, ctx: Context, c: Candle) -> Signal | None:
        s = ctx.state
        t = c.ts.time()
        if t < self.session_start:
            return None

        if "zone" not in s:
            if c.close < c.open:  # first red candle
                s["zone"] = (c.low, c.high)
                s["zone_ts"] = str(c.ts)
                s["trades"] = 0
                zone_pct = (c.high - c.low) / c.close * 100
                s["valid"] = self.p["min_zone_pct"] <= zone_pct <= self.p["max_zone_pct"]
            return None

        if not s.get("valid") or ctx.in_position:
            return None
        if s["trades"] >= self.p["max_trades_per_day"]:
            return None
        hh, mm = map(int, self.p["entry_cutoff"].split(":"))
        if t > time(hh, mm):
            return None

        lo, hi = s["zone"]
        side = None
        if c.close > hi:
            side = BUY
        elif c.close < lo and self.p["allow_short"]:
            side = SELL
        if side is None:
            return None

        if self.p["min_volume_ratio"] > 0:
            earlier = ctx.today["volume"].iloc[:-1]
            if len(earlier) and earlier.mean() > 0 and c.volume / earlier.mean() < self.p["min_volume_ratio"]:
                return None

        mid = (lo + hi) / 2
        buf = c.close * self.p["sl_buffer_pct"] / 100
        if side == BUY:
            sl = (lo if self.p["sl_mode"] == "opposite" else mid) - buf
            risk = c.close - sl
            tgt = c.close + self.p["rr"] * risk
        else:
            sl = (hi if self.p["sl_mode"] == "opposite" else mid) + buf
            risk = sl - c.close
            tgt = c.close - self.p["rr"] * risk
        if risk <= 0:
            return None

        s["trades"] += 1
        return Signal(
            side=side,
            stop_loss=round(sl, 2),
            target=round(tgt, 2),
            reason=f"Close {c.close:.2f} {'above' if side == BUY else 'below'} zone {lo:.2f}-{hi:.2f}",
            tags={"zone_low": lo, "zone_high": hi, "zone_ts": s["zone_ts"]},
        )
