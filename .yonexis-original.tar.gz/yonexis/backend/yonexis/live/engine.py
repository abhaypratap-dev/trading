"""Live loop: candles -> active strategies -> AI score -> risk -> broker -> dashboard (WebSocket).

With LIVE_CONNECTOR=simulated it replays synthetic NSE sessions candle by candle so the
whole system can be exercised when the market is closed.
"""
from __future__ import annotations

import asyncio
import json
import logging
import traceback
from datetime import datetime
from pathlib import Path

import pandas as pd

from yonexis import db
from yonexis.backtest import BacktestConfig, run_backtest
from yonexis.backtest.engine import normalize_candles
from yonexis.broker import get_broker
from yonexis.config import settings
from yonexis.data.connectors import get_connector
from yonexis.data.connectors.simulated import session_index, simulate
from yonexis.ml import TrainedModel, combine, signal_features
from yonexis.risk import risk
from yonexis.strategies import loader

log = logging.getLogger("yonexis.live")


def zone_status(df: pd.DataFrame) -> dict:
    """First-red-candle zone status for the dashboard table."""
    if df.empty:
        return {}
    day = df.index[-1].normalize()
    today = df[df.index >= day]
    last = df.iloc[-1]
    prev_close = df[df.index < day]["close"].iloc[-1] if (df.index < day).any() else today["open"].iloc[0]
    out = {"price": round(float(last["close"]), 2), "ts": str(df.index[-1]),
           "change_pct": round(float((last["close"] / prev_close - 1) * 100), 2),
           "open": float(today["open"].iloc[0]), "high": float(today["high"].max()), "low": float(today["low"].min())}
    red = today[today["close"] < today["open"]]
    if red.empty:
        out["status"] = "WAITING"
        return out
    z = red.iloc[0]
    out["zone_low"], out["zone_high"], out["zone_ts"] = float(z["low"]), float(z["high"]), str(red.index[0])
    out["zone_size"] = round(float(z["high"] - z["low"]), 2)
    out["zone_pct"] = round(float((z["high"] - z["low"]) / z["close"] * 100), 2)
    c = last["close"]
    out["status"] = "ABOVE" if c > z["high"] else "BELOW" if c < z["low"] else "IN ZONE"
    return out


class SimClock:
    """Reveals synthetic candles one by one."""

    def __init__(self, symbols: list[str]):
        today = pd.Timestamp.now().normalize()
        start = (today - pd.tseries.offsets.BDay(25)).strftime("%Y-%m-%d")
        end = (today + pd.tseries.offsets.BDay(120)).strftime("%Y-%m-%d")
        self.full = {s: simulate(s, start, end, seed=i + 11) for i, s in enumerate(symbols)}
        self.days = sorted({d for df in self.full.values() for d in df.index.normalize().unique()})
        first = next((i for i, d in enumerate(self.days) if d >= today), len(self.days) - 1)
        self.day_i, self.k = first, 1
        self.per_day = len(session_index(self.days[0]))

    @property
    def current_day(self) -> pd.Timestamp:
        return self.days[self.day_i]

    def advance(self) -> bool:
        """Reveal one more candle. Returns True when a new day starts."""
        self.k += 1
        if self.k > self.per_day:
            self.day_i = min(self.day_i + 1, len(self.days) - 1)
            self.k = 1
            return True
        return False

    def visible(self, symbol: str) -> pd.DataFrame:
        df = self.full[symbol]
        day = self.current_day
        past = df[df.index < day]
        today = df[(df.index >= day) & (df.index < day + pd.Timedelta(days=1))].iloc[: self.k]
        return pd.concat([past.tail(self.per_day * 15), today])


class LiveEngine:
    def __init__(self):
        self.connector_name = settings.LIVE_CONNECTOR
        self.symbols = list(settings.WATCHLIST)
        self.status: dict[str, dict] = {}
        self.emitted: set[tuple] = set()
        self.subscribers: set[asyncio.Queue] = set()
        self.broker = get_broker()
        self.sim = SimClock(self.symbols) if self.connector_name == "simulated" else None
        self.connector = None if self.sim else get_connector(self.connector_name)
        self._models: dict[str, tuple[str, TrainedModel]] = {}
        self.running = False
        self.last_error: str | None = None
        self.cache: dict[str, pd.DataFrame] = {}
        if self.sim:
            risk.ignore_clock = True

    # ------------------------------------------------------------ data
    def candles(self, symbol: str) -> pd.DataFrame:
        if self.sim:
            return self.sim.visible(symbol)
        df = self.connector.latest_candles(symbol, settings.LIVE_INTERVAL, lookback_days=15)
        df = normalize_candles(df) if not df.empty else df
        if not df.empty:   # drop the still-forming candle
            minutes = int(settings.LIVE_INTERVAL.rstrip("m")) if settings.LIVE_INTERVAL.endswith("m") else 5
            if df.index[-1] + pd.Timedelta(minutes=minutes) > pd.Timestamp.now(tz="Asia/Kolkata").tz_localize(None):
                df = df.iloc[:-1]
        return df

    # ------------------------------------------------------------ models
    def champion(self, kind: str, strategy: str) -> TrainedModel | None:
        rows = [m for m in db.fetch(db.models, order=db.models.c.id) if m["kind"] == kind and m["status"] == "champion"
                and m["strategy"] in (strategy, None, "")]
        if not rows:
            return None
        r = rows[-1]
        cached = self._models.get(f"{kind}:{strategy}")
        if cached and cached[0] == r["version"]:
            return cached[1]
        try:
            m = TrainedModel.load(r["path"])
            self._models[f"{kind}:{strategy}"] = (r["version"], m)
            return m
        except Exception:
            return None

    # ------------------------------------------------------------ loop
    async def publish(self, event: dict) -> None:
        msg = json.dumps(event, default=str)
        for q in list(self.subscribers):
            try:
                q.put_nowait(msg)
            except asyncio.QueueFull:
                pass

    def step(self) -> list[dict]:
        events: list[dict] = []
        strategies = loader.active_live()
        cfg = BacktestConfig(capital_per_trade=risk.limits.capital_per_trade)
        for sym in self.symbols:
            try:
                df = self.candles(sym)
            except Exception as e:
                self.last_error = f"{sym}: {e}"
                continue
            if df.empty:
                continue
            self.cache[sym] = df
            st = zone_status(df)
            today = df.index[-1].normalize()
            for row, cls in strategies:
                res = run_backtest(cls, {sym: df}, db.uj(row["params"], {}) or {}, cfg)
                for s in res.signals:
                    ts = pd.Timestamp(s["ts"])
                    if ts < today:
                        continue
                    key = (row["name"], row["version"], sym, s["ts"])
                    if key in self.emitted:
                        continue
                    self.emitted.add(key)
                    events.append(self._new_signal(row, sym, df, s))
                self._update_outcomes(row, sym, res.trades, today)
                st.setdefault("signal", None)
                todays = [s for s in res.signals if pd.Timestamp(s["ts"]) >= today]
                if todays:
                    st["signal"] = todays[-1]["side"]
            self.status[sym] = st
        events.append({"type": "status", "ts": datetime.now().isoformat(timespec="seconds"),
                       "sim_day": str(self.sim.current_day.date()) if self.sim else None, "rows": self.status})
        return events

    def _new_signal(self, row: dict, sym: str, df: pd.DataFrame, s: dict) -> dict:
        feats = signal_features(df, s["ts"], s["side"], s.get("tags"))
        meta = self.champion("meta", row["name"])
        imit = self.champion("imitation", row["name"])
        ai_p = float(meta.predict_proba([feats])[0]) if meta else None
        ad_p = float(imit.predict_proba([feats])[0]) if imit else None
        score = combine(ai_p, ad_p) if ai_p is not None else ad_p
        sid = db.insert_row(db.signals, ts=pd.Timestamp(s["ts"]).to_pydatetime(), symbol=sym, strategy=row["name"],
                            strategy_version=row["version"], side=s["side"], price=float(s["close"]),
                            stop_loss=s["stop_loss"], target=s["target"], ai_score=ai_p, admin_score=ad_p, score=score,
                            model_version=(meta.version if meta else None), reason=s["reason"],
                            features=db.j(feats), tags=db.j(s.get("tags")), status="open")
        order = None
        if row["status"] in ("paper", "live_small", "live"):
            ok, why, qty = risk.check_entry(sym, s["side"], float(s["close"]), score, row["name"])
            if ok:
                if row["status"] == "paper" or settings.TRADING_MODE != "live":
                    from yonexis.broker import PaperBroker
                    broker = self.broker if isinstance(self.broker, PaperBroker) else PaperBroker()
                else:
                    broker = self.broker
                if row["status"] == "live_small":
                    qty = max(1, qty // 4)
                order = broker.place(sym, s["side"], qty, float(s["close"]), s["stop_loss"], s["target"], f"{row['name']}-{sid}")
                db.update_row(db.signals, sid, status="taken")
                db.log("engine", "order", order)
            else:
                db.update_row(db.signals, sid, status=f"blocked: {why}"[:64])
        return {"type": "signal", "id": sid, "symbol": sym, "strategy": row["name"], "side": s["side"], "ts": s["ts"],
                "price": s["close"], "stop_loss": s["stop_loss"], "target": s["target"], "reason": s["reason"],
                "ai_score": ai_p, "admin_score": ad_p, "score": score, "order": order}

    def _update_outcomes(self, row: dict, sym: str, trades: pd.DataFrame, today: pd.Timestamp) -> None:
        if trades.empty:
            return
        done = trades[(pd.to_datetime(trades["signal_ts"]) >= today) & (trades["exit_reason"] != "end_of_data")]
        if done.empty:
            return
        open_sigs = {str(pd.Timestamp(s["ts"])): s for s in db.fetch(db.signals, (db.signals.c.symbol == sym) &
                     (db.signals.c.strategy == row["name"]) & (db.signals.c.outcome_pnl.is_(None)))}
        for t in done.itertuples():
            s = open_sigs.get(str(pd.Timestamp(t.signal_ts)))
            if s:
                db.update_row(db.signals, s["id"], outcome_pnl=float(t.net_pnl), outcome=t.exit_reason,
                              status="closed" if s["status"] == "taken" else s["status"])
                if s["status"] == "taken":
                    risk.on_exit(sym, float(t.net_pnl))

    async def run(self) -> None:
        self.running = True
        log.info("live engine started: connector=%s symbols=%d", self.connector_name, len(self.symbols))
        while self.running:
            try:
                events = await asyncio.to_thread(self.step)
                for e in events:
                    await self.publish(e)
                self.last_error = None
            except Exception as e:  # keep the loop alive
                self.last_error = f"{e}\n{traceback.format_exc()[-1500:]}"
                log.exception("live step failed")
            if self.sim:
                if self.sim.advance():
                    self.emitted = {k for k in self.emitted if pd.Timestamp(k[3]) >= self.sim.current_day}
                await asyncio.sleep(settings.LIVE_REPLAY_SPEED)
            else:
                await asyncio.sleep(30)

    def stop(self) -> None:
        self.running = False


engine: LiveEngine | None = None
