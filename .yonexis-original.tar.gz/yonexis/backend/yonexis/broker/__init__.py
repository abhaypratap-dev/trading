"""Broker adapters. Paper trading is the default; live needs TRADING_MODE=live and a configured broker."""
from __future__ import annotations

import itertools
from datetime import datetime

from yonexis.config import settings


class PaperBroker:
    name = "paper"
    _ids = itertools.count(1)

    def __init__(self):
        self.orders: list[dict] = []

    def place(self, symbol: str, side: str, qty: int, price: float, stop_loss: float, target: float | None, tag: str) -> dict:
        o = {"order_id": f"PAPER-{next(self._ids)}", "ts": datetime.now().isoformat(timespec="seconds"), "symbol": symbol,
             "side": side, "qty": qty, "price": price, "stop_loss": stop_loss, "target": target, "tag": tag, "status": "FILLED"}
        self.orders.append(o)
        return o

    def square_off(self, symbol: str) -> dict:
        return {"symbol": symbol, "status": "SQUARED_OFF"}


class KiteBroker:
    """Entry as MARKET (brokers convert to price-protected orders under SEBI rules) + an SL-M stop.
    Target is placed as a LIMIT order; whichever fills first should cancel the other (handled by the OMS poller)."""
    name = "kite"

    def __init__(self):
        from yonexis.data.connectors.kite import KiteConnector
        self.k = KiteConnector(settings.KITE_API_KEY, settings.KITE_ACCESS_TOKEN)

    def place(self, symbol: str, side: str, qty: int, price: float, stop_loss: float, target: float | None, tag: str) -> dict:
        exit_side = "SELL" if side == "BUY" else "BUY"
        entry = self.k.place_order(symbol, side, qty, "MARKET", tag=tag)
        sl = self.k.place_order(symbol, exit_side, qty, "SL-M", trigger_price=round(stop_loss, 1), tag=tag)
        tgt = self.k.place_order(symbol, exit_side, qty, "LIMIT", price=round(target, 1), tag=tag) if target else None
        return {"order_id": entry, "sl_order_id": sl, "target_order_id": tgt, "symbol": symbol, "side": side, "qty": qty,
                "status": "PLACED"}

    def square_off(self, symbol: str) -> dict:  # pragma: no cover - live only
        raise NotImplementedError("use Kite's positions API / console to square off")


def get_broker():
    if settings.TRADING_MODE == "live" and settings.BROKER == "kite":
        return KiteBroker()
    return PaperBroker()
