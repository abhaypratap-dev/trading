"""Persistence: candles, datasets, strategies, backtests, live signals, admin feedback, models, audit log.

Runs on TimescaleDB/Postgres in Docker, or SQLite for local development.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

import pandas as pd
from sqlalchemy import (Column, DateTime, Float, Integer, MetaData, String, Table, Text, UniqueConstraint,
                        create_engine, insert, select, text, update)

from .config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True, future=True)
md = MetaData()

candles = Table(
    "candles", md,
    Column("symbol", String(32), primary_key=True),
    Column("interval", String(8), primary_key=True),
    Column("ts", DateTime, primary_key=True),
    Column("open", Float), Column("high", Float), Column("low", Float), Column("close", Float), Column("volume", Float),
    Column("source", String(32)),
)

datasets = Table(
    "datasets", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(200)), Column("kind", String(32)),          # candles | trades | labels
    Column("source", String(64)), Column("rows", Integer), Column("symbols", Text),
    Column("start", String(32)), Column("end", String(32)), Column("meta", Text),
    Column("created_at", DateTime, default=datetime.utcnow),
)

strategies = Table(
    "strategies", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(120)), Column("version", Integer), Column("origin", String(32)),  # builtin|upload|ai|import
    Column("status", String(24), default="candidate"),  # candidate|approved|paper|live_small|live|retired
    Column("code", Text), Column("spec", Text), Column("params", Text), Column("review", Text),
    Column("created_at", DateTime, default=datetime.utcnow),
    UniqueConstraint("name", "version"),
)

backtests = Table(
    "backtests", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("strategy", String(120)), Column("strategy_version", Integer), Column("kind", String(24)),  # quick|full|parity
    Column("params", Text), Column("symbols", Text), Column("start", String(32)), Column("end", String(32)),
    Column("result", Text), Column("created_at", DateTime, default=datetime.utcnow),
)

signals = Table(
    "signals", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("ts", DateTime), Column("symbol", String(32)), Column("strategy", String(120)), Column("strategy_version", Integer),
    Column("side", String(8)), Column("price", Float), Column("stop_loss", Float), Column("target", Float),
    Column("ai_score", Float), Column("admin_score", Float), Column("score", Float), Column("model_version", String(40)),
    Column("reason", Text), Column("features", Text), Column("tags", Text),
    Column("status", String(64), default="open"),   # open|taken|closed|blocked: <reason>
    Column("outcome_pnl", Float), Column("outcome", String(24)),
)

feedback = Table(
    "feedback", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("signal_id", Integer), Column("ts", DateTime, default=datetime.utcnow),
    Column("action", String(16)),           # agree | reject | modify | skip
    Column("new_sl", Float), Column("new_target", Float), Column("remark", Text),
    Column("reasons", Text),                # structured tags extracted from the remark
    Column("features", Text),               # snapshot at feedback time
)

models = Table(
    "models", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("kind", String(24)), Column("version", String(40)), Column("strategy", String(120)),
    Column("path", Text), Column("metrics", Text), Column("status", String(24), default="shadow"),  # shadow|champion|retired
    Column("created_at", DateTime, default=datetime.utcnow),
)

audit = Table(
    "audit", md,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("ts", DateTime, default=datetime.utcnow), Column("actor", String(32)), Column("action", String(64)),
    Column("detail", Text),
)


def init() -> None:
    md.create_all(engine)
    if engine.dialect.name == "postgresql":
        with engine.begin() as cx:
            try:
                cx.execute(text("CREATE EXTENSION IF NOT EXISTS timescaledb"))
                cx.execute(text("SELECT create_hypertable('candles', 'ts', if_not_exists => TRUE, migrate_data => TRUE)"))
            except Exception:
                pass   # plain Postgres works too


def j(x: Any) -> str:
    return json.dumps(x, default=str)


def uj(s: str | None, default=None):
    if not s:
        return default
    try:
        return json.loads(s)
    except Exception:
        return default


def log(actor: str, action: str, detail: Any = None) -> None:
    with engine.begin() as cx:
        cx.execute(insert(audit).values(actor=actor, action=action, detail=j(detail)))


# ----------------------------------------------------------------- candles

def save_candles(symbol: str, df: pd.DataFrame, interval: str, source: str) -> int:
    if df.empty:
        return 0
    d = df.copy()
    d.columns = [c.lower() for c in d.columns]
    d = d.reset_index().rename(columns={d.index.name or "index": "ts"})
    d["ts"] = pd.to_datetime(d["ts"])
    d["symbol"], d["interval"], d["source"] = symbol.upper(), interval, source
    rows = d[["symbol", "interval", "ts", "open", "high", "low", "close", "volume", "source"]].to_dict("records")
    with engine.begin() as cx:
        lo, hi = d["ts"].min(), d["ts"].max()
        cx.execute(candles.delete().where(candles.c.symbol == symbol.upper(), candles.c.interval == interval,
                                          candles.c.ts >= lo, candles.c.ts <= hi))
        for k in range(0, len(rows), 5000):
            cx.execute(insert(candles), rows[k:k + 5000])
    return len(rows)


def load_candles(symbol: str, interval: str = "5m", start: str | None = None, end: str | None = None) -> pd.DataFrame:
    q = select(candles.c.ts, candles.c.open, candles.c.high, candles.c.low, candles.c.close, candles.c.volume).where(
        candles.c.symbol == symbol.upper(), candles.c.interval == interval)
    if start:
        q = q.where(candles.c.ts >= pd.Timestamp(start))
    if end:
        q = q.where(candles.c.ts < pd.Timestamp(end) + pd.Timedelta(days=1))
    with engine.connect() as cx:
        df = pd.read_sql(q.order_by(candles.c.ts), cx)
    return df.set_index("ts") if not df.empty else df


def candle_inventory() -> list[dict]:
    with engine.connect() as cx:
        rows = cx.execute(text("SELECT symbol, interval, COUNT(*) n, MIN(ts) first, MAX(ts) last, MIN(source) source "
                               "FROM candles GROUP BY symbol, interval ORDER BY symbol")).mappings().all()
    return [dict(r) for r in rows]


# ----------------------------------------------------------------- generic helpers

def insert_row(table: Table, **values) -> int:
    with engine.begin() as cx:
        r = cx.execute(insert(table).values(**values))
        return int(r.inserted_primary_key[0])


def update_row(table: Table, row_id: int, **values) -> None:
    with engine.begin() as cx:
        cx.execute(update(table).where(table.c.id == row_id).values(**values))


def fetch(table: Table, where=None, order=None, limit: int | None = None) -> list[dict]:
    q = select(table)
    if where is not None:
        q = q.where(where)
    if order is not None:
        q = q.order_by(order)
    if limit:
        q = q.limit(limit)
    with engine.connect() as cx:
        return [dict(r) for r in cx.execute(q).mappings().all()]
