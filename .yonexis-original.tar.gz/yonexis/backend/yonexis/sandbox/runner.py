"""Sandboxed execution of strategy code.

Two modes:
  * local  - a child Python process with CPU, memory and file limits and a stripped environment.
  * queue  - the job is written to a shared folder and picked up by the `sandbox` container,
             which runs with `network_mode: none` (docker-compose). Default inside Docker.
Either way the child only receives the code, a job description and a data snapshot.
"""
from __future__ import annotations

import json
import os
import pickle
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import pandas as pd

from yonexis.config import settings

from .static_check import check

BACKEND_DIR = Path(__file__).resolve().parents[2]
QUEUE_DIR = Path(os.getenv("SANDBOX_QUEUE_DIR", settings.DATA_DIR / "sandbox_queue"))
MODE = os.getenv("SANDBOX_MODE", "local")


class SandboxError(RuntimeError):
    pass


def _limits():  # runs in the child before exec (POSIX only)
    import resource

    mem = settings.SANDBOX_MEMORY_MB * 1024 * 1024
    try:
        resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
    except (ValueError, OSError):
        pass
    resource.setrlimit(resource.RLIMIT_CPU, (settings.SANDBOX_TIMEOUT, settings.SANDBOX_TIMEOUT + 5))
    resource.setrlimit(resource.RLIMIT_FSIZE, (200 * 1024 * 1024, 200 * 1024 * 1024))
    os.setsid()


def execute_job_dir(job_dir: Path, timeout: int | None = None) -> dict:
    env = {"PYTHONPATH": str(BACKEND_DIR), "PATH": "/usr/bin:/bin", "HOME": str(job_dir),
           "OMP_NUM_THREADS": "1", "MPLBACKEND": "Agg", "PYTHONHASHSEED": "0"}
    try:
        subprocess.run([sys.executable, "-m", "yonexis.sandbox.child", str(job_dir)], cwd=job_dir, env=env,
                       preexec_fn=_limits if os.name == "posix" else None,
                       timeout=timeout or settings.SANDBOX_TIMEOUT, capture_output=True, check=False)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"timed out after {timeout or settings.SANDBOX_TIMEOUT}s"}
    rp = job_dir / "result.json"
    if not rp.exists():
        return {"ok": False, "error": "sandbox produced no result (crashed or exceeded memory)"}
    return json.loads(rp.read_text())


def run(code: str, data: dict[str, pd.DataFrame], job: dict, timeout: int | None = None) -> dict:
    sc = check(code)
    if not sc["ok"]:
        return {"ok": False, "error": "static check failed", "static_check": sc}

    if MODE == "queue":
        QUEUE_DIR.mkdir(parents=True, exist_ok=True)
        job_dir = QUEUE_DIR / f"job-{uuid.uuid4().hex}"
        tmp = job_dir.with_suffix(".writing")
        tmp.mkdir()
    else:
        tmp = Path(tempfile.mkdtemp(prefix="yonexis-sbx-"))
        job_dir = tmp

    (tmp / "strategy.py").write_text(code)
    (tmp / "job.json").write_text(json.dumps(job, default=str))
    with open(tmp / "data.pkl", "wb") as fh:
        pickle.dump(data, fh)

    try:
        if MODE == "queue":
            tmp.rename(job_dir)            # atomic hand-off to the sandbox worker
            deadline = time.time() + (timeout or settings.SANDBOX_TIMEOUT) + 30
            while time.time() < deadline:
                rp = job_dir / "result.json"
                if rp.exists() and (job_dir / "done").exists():
                    out = json.loads(rp.read_text())
                    break
                time.sleep(0.5)
            else:
                out = {"ok": False, "error": "sandbox worker did not answer in time (is the sandbox container running?)"}
        else:
            out = execute_job_dir(job_dir, timeout)
    finally:
        shutil.rmtree(job_dir, ignore_errors=True)
    out["static_check"] = sc
    return out


def worker_loop() -> None:  # pragma: no cover - runs in the sandbox container
    """Entry point of the `sandbox` container: execute jobs dropped into QUEUE_DIR."""
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    print(f"sandbox worker watching {QUEUE_DIR}", flush=True)
    while True:
        for d in sorted(QUEUE_DIR.glob("job-*")):
            if d.suffix == ".writing" or (d / "done").exists() or (d / "running").exists():
                continue
            (d / "running").touch()
            execute_job_dir(d)
            (d / "done").touch()
        time.sleep(0.3)


if __name__ == "__main__":  # pragma: no cover
    worker_loop()
