// YONEXIS dashboard (vanilla JS, no build step)
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
let TOKEN = localStorage.getItem("yx_token") || "";
if (!TOKEN) { TOKEN = prompt("Admin token (ADMIN_TOKEN from .env)") || ""; localStorage.setItem("yx_token", TOKEN); }

async function api(path, opts = {}) {
  const o = { ...opts, headers: { "X-Admin-Token": TOKEN, ...(opts.headers || {}) } };
  if (opts.json !== undefined) { o.body = JSON.stringify(opts.json); o.headers["Content-Type"] = "application/json"; o.method = o.method || "POST"; }
  const r = await fetch(path, o);
  if (r.status === 401) { localStorage.removeItem("yx_token"); alert("Wrong admin token"); location.reload(); }
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("json") ? await r.json() : await r.text();
  if (!r.ok) throw new Error(typeof body === "string" ? body : JSON.stringify(body.detail ?? body, null, 1));
  return body;
}
const fmt = (n, d = 2) => n == null || isNaN(n) ? "—" : Number(n).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d });
const inr = (n, d = 0) => n == null || isNaN(n) ? "—" : (n < 0 ? "-₹" : "₹") + fmt(Math.abs(n), d);
const cls = n => n > 0 ? "green" : n < 0 ? "red" : "";
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const syms = id => $(id).value.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);
const pj = (id) => { const v = $(id).value.trim(); return v ? JSON.parse(v) : {}; };

// ---------------------------------------------------------------- tabs
$$("#tabs button").forEach(b => b.onclick = () => {
  $$("#tabs button").forEach(x => x.classList.toggle("on", x === b));
  $$(".tab").forEach(t => t.classList.toggle("on", t.id === "tab-" + b.dataset.tab));
  const loaders = { models: loadModelsTab, data: loadInventory, feedback: loadFeedback, risk: loadRisk, backtest: loadStrategySelects, import: loadStrategySelects };
  loaders[b.dataset.tab]?.();
});

async function health() {
  try {
    const h = await api("/api/health");
    $("#health").innerHTML = `${h.trading_mode.toUpperCase()} · feed: ${h.connector} · LLM: <span class="${h.llm.ok ? "green" : "red"}">${h.llm.ok ? h.llm.model : "offline"}</span>`;
  } catch (e) { $("#health").textContent = "API offline"; }
}

// ---------------------------------------------------------------- live
let selected = null, chart, series, zoneLines = [], statusRows = {};
function initChart() {
  chart = LightweightCharts.createChart($("#chart"), {
    layout: { background: { color: "#0d1424" }, textColor: "#8a98b4" },
    grid: { vertLines: { color: "#131d33" }, horzLines: { color: "#131d33" } },
    timeScale: { timeVisible: true, secondsVisible: false, borderColor: "#1e2a44" }, rightPriceScale: { borderColor: "#1e2a44" },
    autoSize: true,
  });
  series = chart.addCandlestickSeries({ upColor: "#22c55e", downColor: "#ef4444", borderVisible: false, wickUpColor: "#22c55e", wickDownColor: "#ef4444" });
}
const toUnix = ts => Math.floor(new Date(ts.replace(" ", "T") + "Z").getTime() / 1000);

async function drawChart(sym) {
  const rows = await api(`/api/candles?symbol=${sym}&live_view=true`);
  series.setData(rows.map(r => ({ time: toUnix(r.ts), open: r.open, high: r.high, low: r.low, close: r.close })));
  zoneLines.forEach(l => series.removePriceLine(l)); zoneLines = [];
  const st = statusRows[sym];
  if (st && st.zone_high) {
    zoneLines.push(series.createPriceLine({ price: st.zone_high, color: "#ef4444", lineStyle: 2, lineWidth: 1, title: "zone high" }));
    zoneLines.push(series.createPriceLine({ price: st.zone_low, color: "#ef4444", lineStyle: 2, lineWidth: 1, title: "zone low" }));
  }
  const sigs = (window._signals || []).filter(s => s.symbol === sym && s.ts.slice(0, 10) === (rows.at(-1)?.ts || "").slice(0, 10));
  series.setMarkers(sigs.map(s => ({ time: toUnix(s.ts.replace("T", " ")), position: s.side === "BUY" ? "belowBar" : "aboveBar",
    color: s.side === "BUY" ? "#22c55e" : "#ef4444", shape: s.side === "BUY" ? "arrowUp" : "arrowDown", text: s.side })).sort((a, b) => a.time - b.time));
  chart.timeScale().fitContent();
}

function renderWatch(rows, simDay) {
  statusRows = rows;
  const tb = $("#watch tbody"); tb.innerHTML = "";
  Object.entries(rows).forEach(([sym, r], i) => {
    const stc = r.status === "ABOVE" ? "green" : r.status === "BELOW" ? "red" : "amber";
    const arrow = r.status === "ABOVE" ? "▲ " : r.status === "BELOW" ? "▼ " : "";
    const sig = r.signal ? `<span class="pill ${r.signal.toLowerCase()}">${r.signal}</span>` : `<span class="amber">–</span>`;
    const tr = document.createElement("tr");
    if (sym === selected) tr.className = "sel";
    tr.innerHTML = `<td>${i + 1}</td><td><b class="${sym === selected ? "amber" : ""}">${sym}</b></td><td class="${stc}">${arrow}${r.status || ""}</td><td>${sig}</td><td class="r ${cls(r.change_pct)}">${fmt(r.price)}</td>`;
    tr.onclick = () => { selected = sym; renderWatch(statusRows, simDay); renderCards(simDay); drawChart(sym); };
    tb.appendChild(tr);
  });
  if (!selected && Object.keys(rows).length) { selected = Object.keys(rows)[0]; drawChart(selected); }
  renderCards(simDay);
}

function renderCards(simDay) {
  const r = statusRows[selected]; if (!r) return;
  $("#c-sym").textContent = selected; $("#c-day").textContent = simDay ? `simulated session ${simDay}` : (r.ts || "");
  $("#c-zone").textContent = r.zone_size ? `${fmt(r.zone_size)} (${fmt(r.zone_pct)}%)` : "waiting for first red candle";
  $("#c-price").textContent = fmt(r.price);
  $("#c-chg").innerHTML = `<span class="${cls(r.change_pct)}">${r.change_pct > 0 ? "+" : ""}${fmt(r.change_pct)}%</span>`;
  const sc = r.status === "ABOVE" ? "green" : r.status === "BELOW" ? "red" : "amber";
  $("#c-status").innerHTML = `<span class="${sc}">${r.status === "IN ZONE" ? "IN ZONE" : (r.status || "") + (r.status === "ABOVE" || r.status === "BELOW" ? " ZONE" : "")}</span>`;
  $("#c-signal").innerHTML = r.signal ? `<span class="${r.signal === "BUY" ? "green" : "red"}">${r.signal}</span>` : "—";
}

async function loadCalls() {
  const rows = await api("/api/signals?limit=60");
  window._signals = rows;
  const tb = $("#calls tbody"); tb.innerHTML = "";
  rows.forEach(s => {
    const sc = s.score == null ? `<span class="muted">no model</span>` : `<b class="${s.score >= .5 ? "green" : "red"}">${fmt(s.score * 100, 0)}%</b>`;
    const out = s.outcome_pnl == null ? `<span class="muted">open</span>` : `<span class="${cls(s.outcome_pnl)}">${fmt(s.outcome_pnl, 0)} (${s.outcome})</span>`;
    const fb = s.feedback ? `<span class="muted">${s.feedback.action}${s.feedback.remark ? ": " + esc(s.feedback.remark).slice(0, 40) : ""}</span>` :
      `<button class="sm" data-a="agree">✓ Agree</button> <button class="sm" data-a="reject">✗ Reject</button> <button class="sm" data-a="modify">✎ Modify</button> <button class="sm" data-a="skip">Skip</button>`;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${s.ts.slice(5, 16).replace("T", " ")}</td><td><b>${s.symbol}</b></td><td><span class="pill ${s.side.toLowerCase()}">${s.side}</span></td>
      <td class="r">${fmt(s.price)}</td><td class="r">${fmt(s.stop_loss)}</td><td class="r">${fmt(s.target)}</td><td>${sc}</td><td class="muted">${esc(s.status)}</td><td>${out}</td><td>${fb}</td>`;
    $$("button", tr).forEach(b => b.onclick = () => feedbackDialog(s, b.dataset.a));
    tb.appendChild(tr);
  });
}

function feedbackDialog(s, action) {
  const d = $("#dlg");
  $("#dlg-body").innerHTML = `<div class="panel-h">${action.toUpperCase()} · ${s.side} ${s.symbol} @ ${fmt(s.price)}</div>
    <p class="muted">${esc(s.reason)}</p>
    ${action === "modify" ? `<div class="form"><label>New SL <input id="fb-sl" type="number" step="0.05" value="${s.stop_loss}"></label><label>New target <input id="fb-tg" type="number" step="0.05" value="${s.target ?? ""}"></label></div>` : ""}
    <label class="muted">Remark (why?) — this becomes training data<textarea id="fb-remark" rows="3" placeholder="e.g. results tomorrow, resistance at 2700, volume fake"></textarea></label>`;
  d.showModal();
  d.onclose = async () => {
    if (d.returnValue !== "ok") return;
    const body = { action, remark: $("#fb-remark").value };
    if (action === "modify") { body.new_sl = parseFloat($("#fb-sl").value); body.new_target = parseFloat($("#fb-tg").value); }
    try { await api(`/api/signals/${s.id}/feedback`, { json: body }); loadCalls(); } catch (e) { alert(e.message); }
  };
}

function connectWS() {
  const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws/live?token=${encodeURIComponent(TOKEN)}`);
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.type === "status") {
      renderWatch(m.rows, m.sim_day);
      $("#clock").textContent = (m.rows[selected]?.ts || "").slice(11, 16);
      if (selected) drawChart(selected);
    } else if (m.type === "signal") loadCalls();
  };
  ws.onclose = () => setTimeout(connectWS, 3000);
}

// ---------------------------------------------------------------- backtest
async function loadStrategySelects() {
  const rows = await api("/api/strategies");
  const latest = {}; rows.forEach(r => latest[r.name] = r);
  const opts = Object.values(latest).map(r => `<option value="${r.name}">${r.name} (v${r.version}, ${r.status})</option>`).join("");
  ["#bt-strategy", "#par-strategy", "#tm-strategy"].forEach(id => { const v = $(id).value; $(id).innerHTML = opts; if (v) $(id).value = v; });
}

function metricsKV(m) {
  if (!m || !m.trades) return `<p class="muted">No trades.</p>`;
  const items = [["Trades", m.trades], ["Net P&L (after costs)", `<span class="${cls(m.net_pnl)}">${inr(m.net_pnl)}</span>`],
    ["Costs paid", `${inr(m.total_costs)}`], ["Win rate", fmt(m.win_rate) + "%"], ["Avg win / loss", `${inr(m.avg_win)} / ${inr(m.avg_loss)}`],
    ["Profit factor", fmt(m.profit_factor, 2)], ["Sharpe", fmt(m.sharpe, 2)], ["Max drawdown", `${inr(m.max_drawdown)} (${fmt(m.max_drawdown_pct)}%)`],
    ["Trades / month", fmt(m.trades_per_month, 1)], ["Period", `${(m.start || "").slice(0, 10)} → ${(m.end || "").slice(0, 10)}`]];
  return `<div class="kv">${items.map(([k, v]) => `<div>${k}</div><div>${v}</div>`).join("")}</div>`;
}

function equityChart(el, daily) {
  if (!daily || !daily.length) return;
  const c = LightweightCharts.createChart(el, { height: 220, autoSize: true, layout: { background: { color: "#0d1424" }, textColor: "#8a98b4" },
    grid: { vertLines: { color: "#131d33" }, horzLines: { color: "#131d33" } } });
  c.addAreaSeries({ lineColor: "#38bdf8", topColor: "rgba(56,189,248,.25)", bottomColor: "rgba(56,189,248,0)" })
    .setData(daily.map(d => ({ time: d.date.slice(0, 10), value: d.equity })));
  c.timeScale().fitContent();
}

function evaluationHTML(ev) {
  const v = (ev.verdict || "").toLowerCase();
  const checks = Object.entries(ev.checks || {}).map(([k, ok]) => `<span class="${ok ? "ok" : "no"}">${ok ? "✓" : "✗"} ${k.replaceAll("_", " ")}</span>`).join("");
  const mc = ev.monte_carlo || {}, wf = ev.walk_forward || {}, st = ev.stress || {};
  const regimes = Object.entries(ev.regimes || {}).map(([r, x]) => `<tr><td>${r}</td><td class="r">${x.trades}</td><td class="r ${cls(x.net_pnl)}">${fmt(x.net_pnl, 0)}</td><td class="r">${fmt(x.win_rate)}%</td></tr>`).join("");
  const stressRows = ["costs_x2", "slippage_x2", "slippage_x4"].map(k => st[k] ? `<tr><td>${k.replace("_", " ")}</td><td class="r ${cls(st[k].net_pnl)}">${fmt(st[k].net_pnl, 0)}</td></tr>` : "").join("")
    + Object.entries(st.historical_windows || {}).filter(([k]) => k !== "note").map(([k, x]) => `<tr><td>${k}</td><td class="r ${cls(x.net_pnl)}">${fmt(x.net_pnl, 0)}</td></tr>`).join("");
  return `<div class="panel"><div class="panel-h"><span>Verdict <span class="pill ${v}">${ev.verdict}</span> · ${ev.score} checks passed</span><span class="muted">deflated Sharpe ${fmt(ev.deflated_sharpe_prob, 3)} · ${ev.n_trials} variants tried</span></div><div class="checks">${checks}</div></div>
  <div class="grid2">
    <div class="panel"><div class="panel-h">Development period</div>${metricsKV(ev.development)}</div>
    <div class="panel"><div class="panel-h">Locked holdout (never seen in tuning)</div>${metricsKV(ev.holdout)}</div>
    <div class="panel"><div class="panel-h">Monte Carlo (${mc.n_sims || 0} runs)</div><div class="kv">
      <div>Net P&L 5th / 50th / 95th pct</div><div>${inr(mc.net_pnl_p5)} / ${inr(mc.net_pnl_p50)} / ${inr(mc.net_pnl_p95)}</div>
      <div>Probability of loss</div><div>${fmt(mc.prob_loss)}%</div><div>95% worst drawdown</div><div>${inr(mc.max_dd_p95_worst)}</div></div></div>
    <div class="panel"><div class="panel-h">Walk-forward (out of sample)</div>${wf.oos_metrics ? metricsKV(wf.oos_metrics) + `<p class="muted">${wf.pct_profitable_folds}% of ${wf.folds.length} folds profitable</p>` : `<p class="muted">${wf.note || "No parameter grid given."}</p>`}</div>
    <div class="panel"><div class="panel-h">Stress tests (net P&L)</div><table class="tbl">${stressRows}</table></div>
    <div class="panel"><div class="panel-h">By market regime</div><table class="tbl"><tr><th>Regime</th><th class="r">Trades</th><th class="r">Net P&L</th><th class="r">Win %</th></tr>${regimes}</table>
      <p class="muted">Parameter sensitivity: ${ev.sensitivity?.fragile ? '<b class="red">fragile</b>' : '<span class="green">stable</span>'} (worst ±10% move: ${inr(ev.sensitivity?.worst_net_pnl)})</p></div>
  </div>
  ${ev.report ? `<div class="panel"><div class="panel-h">Report agent</div><div class="prose">${esc(ev.report)}</div></div>` : ""}
  ${ev.critic ? `<div class="panel"><div class="panel-h">Critic agent (red team)</div><div class="prose">${esc(ev.critic)}</div></div>` : ""}`;
}

async function pollJob(jid, onLog) {
  while (true) {
    const j = await api(`/api/jobs/${jid}`);
    onLog?.(j);
    if (j.status !== "running") return j;
    await new Promise(r => setTimeout(r, 1500));
  }
}

function btBody() {
  return { strategy: $("#bt-strategy").value, symbols: syms("#bt-symbols"), interval: $("#bt-interval").value, start: $("#bt-start").value,
    end: $("#bt-end").value, source: $("#bt-source").value, params: pj("#bt-params"),
    param_space: $("#bt-space").value.trim() ? JSON.parse($("#bt-space").value) : null,
    baseline_net_pnl: $("#bt-baseline").value ? parseFloat($("#bt-baseline").value) : null };
}
$("#bt-quick").onclick = async () => {
  $("#bt-out").innerHTML = `<div class="panel muted">Running…</div>`;
  try {
    const r = await api("/api/backtests/quick", { json: btBody() });
    $("#bt-out").innerHTML = `<div class="grid2"><div class="panel"><div class="panel-h">Results</div>${metricsKV(r.metrics)}</div><div class="panel"><div class="panel-h">Equity</div><div id="eq"></div></div></div>
      <div class="panel"><div class="panel-h">Trades (first 200)</div><table class="tbl"><tr><th>Symbol</th><th>Side</th><th>Entry</th><th class="r">Price</th><th>Exit</th><th class="r">Price</th><th>Why</th><th class="r">Net P&L</th></tr>
      ${r.trades.slice(0, 200).map(t => `<tr><td>${t.symbol}</td><td>${t.side}</td><td>${t.entry_ts.slice(0, 16)}</td><td class="r">${fmt(t.entry)}</td><td>${t.exit_ts.slice(11, 16)}</td><td class="r">${fmt(t.exit)}</td><td class="muted">${t.exit_reason}</td><td class="r ${cls(t.net_pnl)}">${fmt(t.net_pnl, 0)}</td></tr>`).join("")}</table></div>`;
    equityChart($("#eq"), r.daily);
  } catch (e) { $("#bt-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};
$("#bt-full").onclick = async () => {
  $("#bt-out").innerHTML = `<div class="panel"><span class="muted">Full evaluation running: walk-forward, Monte Carlo, sensitivity, stress, regimes, holdout… this can take a few minutes.</span></div>`;
  try {
    const { job_id } = await api("/api/backtests/full", { json: btBody() });
    const j = await pollJob(job_id);
    if (j.status === "error") throw new Error(j.error);
    $("#bt-out").innerHTML = evaluationHTML(j.result);
  } catch (e) { $("#bt-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- AI builder
$("#ai-spec").onclick = async () => {
  $("#ai-spec-status").textContent = "Spec agent is reading your idea…";
  try {
    const card = await api("/api/agents/spec", { json: { prompt: $("#ai-prompt").value } });
    $("#ai-card").value = JSON.stringify(card, null, 2);
    $("#ai-questions").innerHTML = (card.questions || []).map(q => `<div class="q">❓ ${esc(q)}</div>`).join("") +
      ((card.questions || []).length ? `<p class="muted">Answer these by editing the card below (or add the answer to your idea and create the card again).</p>` : "");
    $("#ai-card-panel").hidden = false; $("#ai-spec-status").textContent = "";
  } catch (e) { $("#ai-spec-status").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
};
$("#ai-build").onclick = async () => {
  let spec; try { spec = JSON.parse($("#ai-card").value); } catch { return alert("Rule card is not valid JSON"); }
  $("#ai-progress").hidden = false; $("#ai-log").textContent = ""; $("#ai-out").innerHTML = "";
  try {
    const { job_id } = await api("/api/agents/build", { json: { spec, symbols: syms("#ai-symbols"), start: $("#ai-start").value, end: $("#ai-end").value,
      source: $("#ai-source").value, baseline_net_pnl: $("#ai-baseline").value ? parseFloat($("#ai-baseline").value) : null } });
    const j = await pollJob(job_id, j => { $("#ai-log").textContent = j.log.map(l => `[${l.t}s] ${l.stage} ${JSON.stringify(Object.fromEntries(Object.entries(l).filter(([k]) => !["t", "stage"].includes(k))))}`).join("\n"); });
    if (j.status === "error") throw new Error(j.error + "\n" + (j.trace || ""));
    const r = j.result;
    if (!r.ok) { $("#ai-out").innerHTML = `<div class="panel"><div class="panel-h red">Stopped at: ${r.stage}</div><pre class="log">${esc(JSON.stringify(r.problems || r.error, null, 2))}</pre><pre class="log">${esc(r.code)}</pre></div>`; return; }
    $("#ai-out").innerHTML = `<div class="panel"><div class="panel-h">Saved as <b>${r.saved?.name} v${r.saved?.version}</b> (candidate). Approve it in Strategies &amp; Models.</div></div>` +
      evaluationHTML({ ...r.evaluation, critic: r.critic, report: r.report }) +
      `<div class="panel"><div class="panel-h">Generated code</div><pre class="log">${esc(r.code)}</pre></div>`;
  } catch (e) { $("#ai-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- import & parity
$("#imp-convert").onclick = async () => {
  $("#imp-status").textContent = "Converter agent working…"; $("#imp-out").innerHTML = "";
  try {
    const { job_id } = await api("/api/import/convert", { json: { source: $("#imp-src").value, language: $("#imp-lang").value, notes: $("#imp-notes").value, name: $("#imp-name").value || null } });
    const j = await pollJob(job_id, j => $("#imp-status").textContent = `stage: ${j.stage}`);
    if (j.status === "error") throw new Error(j.error);
    const r = j.result;
    $("#imp-status").textContent = r.saved ? `Saved as ${r.saved.name} v${r.saved.version}. Now run a parity check below.` : "Not saved: review found problems.";
    $("#imp-out").innerHTML = `<pre class="log">${esc(JSON.stringify({ approved: r.review.approved, issues: r.review.issues, static: r.review.static_check }, null, 2))}</pre><pre class="log">${esc(r.code)}</pre>`;
    loadStrategySelects();
  } catch (e) { $("#imp-status").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
};
$("#par-run").onclick = async () => {
  const f = $("#par-file").files[0]; if (!f) return alert("Choose the admin's trades file");
  const fd = new FormData(); fd.append("file", f); fd.append("strategy", $("#par-strategy").value); fd.append("interval", $("#par-interval").value); fd.append("params", $("#par-params").value || "{}");
  $("#par-out").innerHTML = `<p class="muted">Comparing trade by trade…</p>`;
  try {
    const r = await api("/api/import/parity", { method: "POST", body: fd });
    $("#par-out").innerHTML = `<div class="panel-h">Verdict: <span class="pill ${r.verdict === "PARITY" ? "pass" : r.verdict === "CLOSE" ? "review" : "fail"}">${r.verdict}</span> ${fmt(r.match_rate_pct)}% matched</div>
      <div class="kv"><div>Admin trades</div><div>${r.admin_trades}</div><div>Our trades</div><div>${r.our_trades}</div><div>Matched</div><div>${r.matched}</div><div>Shifted</div><div>${r.shifted}</div><div>Missing</div><div>${r.missing}</div><div>Extra</div><div>${r.extra}</div>
      ${r.admin_net_pnl != null ? `<div>Admin net P&L</div><div>${inr(r.admin_net_pnl)}</div><div>Our net P&L</div><div>${inr(r.our_net_pnl)}</div>` : ""}</div>
      <p>${r.likely_causes.map(esc).join("<br>")}</p><pre class="log">${esc(JSON.stringify(r.examples, null, 1))}</pre>`;
  } catch (e) { $("#par-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- data
const today = new Date(); $("#df-end").value = today.toISOString().slice(0, 10);
$("#df-start").value = new Date(today - 55 * 864e5).toISOString().slice(0, 10);
$("#df-go").onclick = async () => {
  $("#df-out").textContent = "Fetching…";
  try { const r = await api("/api/data/fetch", { json: { symbols: syms("#df-symbols"), source: $("#df-source").value, interval: $("#df-interval").value, start: $("#df-start").value, end: $("#df-end").value } });
    $("#df-out").textContent = JSON.stringify(r, null, 2); loadInventory(); } catch (e) { $("#df-out").textContent = e.message; }
};
$("#up-preview").onclick = async () => {
  const f = $("#up-file").files[0]; if (!f) return; const fd = new FormData(); fd.append("file", f);
  try { const r = await api("/api/data/upload/preview", { method: "POST", body: fd }); $("#up-out").textContent = JSON.stringify(r, null, 2);
    $("#up-kind").value = r.kind_guess === "trades" ? "trades" : "candles"; } catch (e) { $("#up-out").textContent = e.message; }
};
$("#up-go").onclick = async () => {
  const f = $("#up-file").files[0]; if (!f) return; const fd = new FormData();
  fd.append("file", f); fd.append("kind", $("#up-kind").value); fd.append("symbol", $("#up-symbol").value); fd.append("interval", $("#up-interval").value); fd.append("mapping", $("#up-mapping").value || "{}");
  $("#up-out").textContent = "Validating…";
  try { const r = await api("/api/data/upload", { method: "POST", body: fd }); $("#up-out").textContent = JSON.stringify(r, null, 2); loadInventory(); } catch (e) { $("#up-out").textContent = e.message; }
};
async function loadInventory() {
  const r = await api("/api/data/inventory");
  $("#inv tbody").innerHTML = r.candles.map(c => `<tr><td>${c.symbol}</td><td>${c.interval}</td><td class="r">${c.n}</td><td>${String(c.first).slice(0, 16)}</td><td>${String(c.last).slice(0, 16)}</td><td class="muted">${c.source}</td></tr>`).join("") || `<tr><td colspan="6" class="muted">No data yet.</td></tr>`;
}

// ---------------------------------------------------------------- models & strategies
const STATUSES = ["candidate", "approved", "paper", "live_small", "live", "retired"];
async function loadModelsTab() {
  await loadStrategySelects();
  const st = await api("/api/strategies");
  $("#strats tbody").innerHTML = st.map(r => `<tr><td><b>${r.name}</b></td><td>${r.version}</td><td class="muted">${r.origin}</td><td class="muted">${String(r.created_at).slice(0, 16)}</td>
    <td><select data-n="${r.name}" data-v="${r.version}">${STATUSES.map(s => `<option ${s === r.status ? "selected" : ""}>${s}</option>`).join("")}</select></td>
    <td><button class="sm" data-code="${r.id}">code</button></td></tr>`).join("");
  $$("#strats select").forEach(s => s.onchange = async () => { try { await api(`/api/strategies/${s.dataset.n}/${s.dataset.v}/status`, { json: { status: s.value } }); } catch (e) { alert(e.message); loadModelsTab(); } });
  $$("#strats [data-code]").forEach(b => b.onclick = () => { const r = st.find(x => x.id == b.dataset.code); $("#dlg-body").innerHTML = `<pre class="log" style="max-height:70vh;min-width:60vw">${esc(r.code)}</pre>`; $("#dlg").showModal(); });
  const ms = await api("/api/models");
  $("#models tbody").innerHTML = ms.map(m => `<tr><td>${m.kind}</td><td>${m.version}</td><td>${m.strategy || "all"}</td><td>${fmt(m.metrics.oos_auc, 3)}</td>
    <td>${fmt((m.metrics.hit_rate_top40pct || 0) * 100, 1)}% / ${fmt((m.metrics.hit_rate_all || 0) * 100, 1)}%</td><td>${m.status}</td>
    <td>${m.status !== "champion" ? `<button class="sm" data-p="${m.id}">promote</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="7" class="muted">No models yet.</td></tr>`;
  $$("#models [data-p]").forEach(b => b.onclick = async () => { await api(`/api/models/${b.dataset.p}/promote`, { method: "POST" }); loadModelsTab(); });
  const bts = await api("/api/backtests");
  $("#bts tbody").innerHTML = bts.map(b => { const s = b.summary || {}; return `<tr><td>${b.id}</td><td>${b.kind}</td><td>${b.strategy} v${b.strategy_version}</td><td>${s.verdict ? `<span class="pill ${s.verdict.toLowerCase()}">${s.verdict}</span>` : ""}</td>
    <td class="r">${s.trades ?? ""}</td><td class="r ${cls(s.net_pnl)}">${fmt(s.net_pnl, 0)}</td><td class="r">${fmt(s.win_rate)}</td><td class="r">${fmt(s.profit_factor)}</td><td class="r">${fmt(s.sharpe)}</td>
    <td>${b.kind === "full" ? `<button class="sm" data-b="${b.id}">open</button>` : ""}</td></tr>`; }).join("");
  $$("#bts [data-b]").forEach(x => x.onclick = async () => { const b = await api(`/api/backtests/${x.dataset.b}`); $$("#tabs button")[1].click(); $("#bt-out").innerHTML = evaluationHTML(b.result); });
}
$("#tm-go").onclick = async () => {
  $("#tm-status").textContent = "Training…";
  try { const { job_id } = await api("/api/models/train-meta", { json: { strategy: $("#tm-strategy").value, symbols: syms("#tm-symbols"), start: $("#tm-start").value, end: $("#tm-end").value, source: $("#tm-source").value } });
    const j = await pollJob(job_id, j => $("#tm-status").textContent = `stage: ${j.stage}`);
    $("#tm-status").textContent = j.status === "done" ? `Trained ${j.result.version}: OOS AUC ${fmt(j.result.metrics.oos_auc, 3)}` : j.error; loadModelsTab();
  } catch (e) { $("#tm-status").textContent = e.message; }
};
$("#ti-go").onclick = async () => { try { const r = await api("/api/models/train-imitation", { method: "POST" }); $("#tm-status").textContent = `Imitation model: OOS AUC ${fmt(r.metrics.oos_auc, 3)}`; loadModelsTab(); } catch (e) { $("#tm-status").textContent = e.message; } };

// ---------------------------------------------------------------- feedback
async function loadFeedback() {
  const s = await api("/api/feedback/scoreboard");
  const card = (k, v, c = "") => `<div class="card"><div class="k">${k}</div><div class="v ${c}">${v}</div></div>`;
  $("#fb-cards").innerHTML = card("Calls with outcome", s.calls_with_outcome) + card("Calls you reviewed", s.calls_with_feedback) +
    card("AI alone P&L", inr(s.ai_alone_pnl), cls(s.ai_alone_pnl)) + card("Your filter P&L", inr(s.admin_filtered_pnl), cls(s.admin_filtered_pnl)) +
    card("Combined P&L", inr(s.combined_pnl), cls(s.combined_pnl)) + card("Your decision accuracy", s.admin_decision_accuracy_pct == null ? "—" : s.admin_decision_accuracy_pct + "%");
  $("#fb-tags tbody").innerHTML = Object.entries(s.by_tag).map(([t, d]) => `<tr><td>${t}</td><td class="r">${d.count}</td><td class="r">${d.rejected}</td><td class="r">${d.admin_right_pct}%</td></tr>`).join("") || `<tr><td colspan="4" class="muted">Add remarks to live calls to see patterns.</td></tr>`;
}
$("#fb-suggest").onclick = async () => {
  $("#fb-sugg").innerHTML = `<p class="muted">Thinking…</p>`;
  try { const r = await api("/api/feedback/suggestions", { method: "POST" });
    $("#fb-sugg").innerHTML = r.suggestions.map(s => `<div class="panel"><b>${esc(s.title)}</b><p class="muted">${esc(s.evidence)}</p><button class="sm" data-p="${esc(s.prompt_for_builder)}">Send to AI Builder</button></div>`).join("") || `<p class="muted">Not enough reviewed calls yet.</p>`;
    $$("#fb-sugg [data-p]").forEach(b => b.onclick = () => { $("#ai-prompt").value = b.dataset.p; $$("#tabs button")[2].click(); });
  } catch (e) { $("#fb-sugg").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- risk
async function loadRisk() {
  $("#rk-out").textContent = JSON.stringify(await api("/api/risk"), null, 2);
  const a = await api("/api/audit");
  $("#audit tbody").innerHTML = a.map(r => `<tr><td>${String(r.ts).slice(0, 19)}</td><td>${r.actor}</td><td>${r.action}</td><td class="muted">${esc(r.detail).slice(0, 160)}</td></tr>`).join("");
}
$("#rk-kill").onclick = async () => { if (confirm("Stop all new orders now?")) { await api("/api/risk/kill", { method: "POST" }); loadRisk(); } };
$("#rk-reset").onclick = async () => { await api("/api/risk/reset", { method: "POST" }); loadRisk(); };

// ---------------------------------------------------------------- boot
initChart(); health(); setInterval(health, 30000); connectWS(); loadCalls(); setInterval(loadCalls, 15000); loadStrategySelects();
api("/api/live/status").then(s => s.rows && renderWatch(s.rows, s.sim_day)).catch(() => {});
