"""Paper trading: every call is filled against live prices and recorded in the database. Nothing goes to a broker.

Fill model (deliberately a little pessimistic):
  * Entry at the live last-traded price when the call is made, plus slippage.
  * Stop: BUY exits at min(stop, LTP), SELL at max(stop, LTP), plus slippage, so gaps through the stop hurt.
    The stop is checked before the target when both are touched in the same update.
  * Target: filled at the target price (a resting limit order).
  * Square-off at 15:15 at the live price, plus slippage.
  * Full Indian intraday costs (backtest/costs.py) are deducted from the demo wallet on exit.
"""
from __future__ import annotations

import logging
import threading
from datetime import datetime

from sqlalchemy import insert, select, update

from yonexis import db
from yonexis.backtest.costs import CostModel
from yonexis.config import settings

log = logging.getLogger("yonexis.paper")


class InsufficientFunds(RuntimeError):
    pass


class Wallet:
    """Demo money for paper trading. One row; every change is written to the ledger."""

    def __init__(self, default_balance: float | None = None):
        self.default = float(default_balance or settings.PAPER_STARTING_BALANCE)
        self._lock = threading.Lock()

    def _row(self, cx) -> dict:
        r = cx.execute(select(db.wallet).where(db.wallet.c.id == 1)).mappings().first()
        if r is None:
            cx.execute(insert(db.wallet).values(id=1, balance=self.default, starting_balance=self.default))
            cx.execute(insert(db.wallet_ledger).values(kind="reset", amount=self.default, balance_after=self.default,
                                                       note="initial demo money"))
            r = cx.execute(select(db.wallet).where(db.wallet.c.id == 1)).mappings().first()
        return dict(r)

    def get(self) -> dict:
        with db.engine.begin() as cx:
            return self._row(cx)

    def blocked(self) -> float:
        rows = db.fetch(db.paper_trades, db.paper_trades.c.status == "open")
        return round(sum(r["margin"] or 0 for r in rows), 2)

    def available(self) -> float:
        return round(self.get()["balance"] - self.blocked(), 2)

    def _move(self, amount: float, kind: str, ref: str = "", note: str = "") -> float:
        with self._lock, db.engine.begin() as cx:
            w = self._row(cx)
            bal = round(w["balance"] + amount, 2)
            cx.execute(update(db.wallet).where(db.wallet.c.id == 1).values(balance=bal, updated_at=datetime.utcnow()))
            cx.execute(insert(db.wallet_ledger).values(kind=kind, amount=round(amount, 2), balance_after=bal, ref=ref, note=note))
            return bal

    def deposit(self, amount: float, note: str = "") -> float:
        if amount <= 0:
            raise ValueError("amount must be positive")
        return self._move(amount, "deposit", note=note or "demo top-up")

    def reset(self, amount: float | None = None) -> float:
        if db.fetch(db.paper_trades, db.paper_trades.c.status == "open"):
            raise ValueError("close open paper positions before resetting the wallet")
        amount = float(amount or self.default)
        with self._lock, db.engine.begin() as cx:
            self._row(cx)
            cx.execute(update(db.wallet).where(db.wallet.c.id == 1).values(balance=amount, starting_balance=amount,
                                                                           updated_at=datetime.utcnow()))
            cx.execute(insert(db.wallet_ledger).values(kind="reset", amount=amount, balance_after=amount, note="wallet reset"))
        return amount

    def book(self, net_pnl: float, trade_id: int, note: str) -> float:
        return self._move(net_pnl, "trade", ref=f"paper_trade:{trade_id}", note=note)


class PaperBroker:
    name = "paper"

    def __init__(self, costs: CostModel | None = None, slippage_bps: float | None = None, leverage: float | None = None):
        self.costs = costs or CostModel()
        self.slippage_bps = settings.PAPER_SLIPPAGE_BPS if slippage_bps is None else slippage_bps
        self.leverage = max(1.0, float(leverage or settings.PAPER_LEVERAGE))
        self.wallet = Wallet()
        self._lock = threading.Lock()
        self.restore_risk()

    # ------------------------------------------------------------------ helpers
    def _slip(self, px: float, side: str, entering: bool) -> float:
        up = (side == "BUY") == entering
        k = self.slippage_bps / 10_000
        return round(px * (1 + k if up else 1 - k), 2)

    def open_trades(self) -> list[dict]:
        return db.fetch(db.paper_trades, db.paper_trades.c.status == "open", order=db.paper_trades.c.id)

    def restore_risk(self) -> None:
        """After a restart, tell the risk engine about open paper positions and today's realised P&L."""
        try:
            from yonexis.risk import risk
            for t in self.open_trades():
                risk.state.open_positions[t["symbol"]] = {"qty": t["qty"], "value": t["qty"] * t["entry_price"],
                                                          "side": t["side"], "strategy": t["strategy"]}
            today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            done = [t for t in db.fetch(db.paper_trades, db.paper_trades.c.status == "closed")
                    if t["exit_ts"] and t["exit_ts"] >= today]
            risk.state.day = datetime.now().strftime("%Y-%m-%d")
            risk.state.realized_pnl = round(sum(t["net_pnl"] or 0 for t in done), 2)
        except Exception as e:  # pragma: no cover
            log.warning("could not restore risk state: %s", e)

    # ------------------------------------------------------------------ orders
    def place(self, symbol: str, side: str, qty: int, price: float, stop_loss: float, target: float | None, tag: str,
              signal_id: int | None = None, strategy: str | None = None, ts: datetime | None = None) -> dict:
        with self._lock:
            entry = self._slip(float(price), side, entering=True)
            avail = self.wallet.available()
            max_qty = int(avail * self.leverage // entry)
            if max_qty <= 0:
                raise InsufficientFunds(f"demo wallet has Rs {avail:,.0f} available")
            qty = min(int(qty), max_qty)
            if (side == "BUY" and entry <= stop_loss) or (side == "SELL" and entry >= stop_loss):
                raise ValueError(f"price {entry} already beyond the stop {stop_loss}")
            margin = round(qty * entry / self.leverage, 2)
            tid = db.insert_row(db.paper_trades, signal_id=signal_id, strategy=strategy, symbol=symbol, side=side, qty=qty,
                                margin=margin, ref_price=float(price), entry_price=entry, entry_ts=ts or datetime.now(),
                                stop_loss=float(stop_loss), target=float(target) if target else None, status="open",
                                last_price=float(price), tag=tag)
        db.log("paper", "open", {"trade_id": tid, "symbol": symbol, "side": side, "qty": qty, "entry": entry})
        return {"order_id": f"PAPER-{tid}", "trade_id": tid, "symbol": symbol, "side": side, "qty": qty, "price": entry,
                "stop_loss": stop_loss, "target": target, "margin": margin, "status": "FILLED (paper)", "broker": "paper"}

    def close(self, trade_id: int, price: float, reason: str, ts: datetime | None = None, slip: bool = True) -> dict | None:
        with self._lock:
            rows = db.fetch(db.paper_trades, (db.paper_trades.c.id == trade_id) & (db.paper_trades.c.status == "open"))
            if not rows:
                return None
            t = rows[0]
            px = self._slip(price, t["side"], entering=False) if slip else round(price, 2)
            d = 1 if t["side"] == "BUY" else -1
            gross = round((px - t["entry_price"]) * t["qty"] * d, 2)
            buy_v = t["entry_price"] * t["qty"] if d == 1 else px * t["qty"]
            sell_v = px * t["qty"] if d == 1 else t["entry_price"] * t["qty"]
            cost = round(self.costs.round_trip(buy_v, sell_v), 2)
            net = round(gross - cost, 2)
            db.update_row(db.paper_trades, trade_id, status="closed", exit_price=px, exit_ts=ts or datetime.now(),
                          exit_reason=reason, gross_pnl=gross, costs=cost, net_pnl=net, last_price=price)
            bal = self.wallet.book(net, trade_id, f"{t['side']} {t['qty']} {t['symbol']} {reason}")
        if t["signal_id"]:
            db.update_row(db.signals, t["signal_id"], outcome_pnl=net, outcome=reason, status="closed")
        try:
            from yonexis.risk import risk
            risk.on_exit(t["symbol"], net)
        except Exception:
            pass
        db.log("paper", "close", {"trade_id": trade_id, "symbol": t["symbol"], "exit": px, "reason": reason, "net_pnl": net})
        return {"trade_id": trade_id, "symbol": t["symbol"], "exit": reason, "price": px, "net_pnl": net, "balance": bal}

    def manage(self, quotes: dict[str, dict], square_off: bool, ts: datetime | None = None) -> list[dict]:
        """quotes: {symbol: {"ltp": .., "high": .., "low": ..}} (high/low = range since the last update)."""
        out = []
        for t in self.open_trades():
            q = quotes.get(t["symbol"]) or {}
            ltp = q.get("ltp")
            if ltp is None:
                continue
            hi, lo = q.get("high", ltp), q.get("low", ltp)
            sl, tgt = t["stop_loss"], t["target"]
            r = None
            if t["side"] == "BUY":
                if lo <= sl:
                    r = self.close(t["id"], min(sl, ltp), "stop_loss", ts)
                elif tgt is not None and hi >= tgt:
                    r = self.close(t["id"], tgt, "target", ts, slip=False)
            else:
                if hi >= sl:
                    r = self.close(t["id"], max(sl, ltp), "stop_loss", ts)
                elif tgt is not None and lo <= tgt:
                    r = self.close(t["id"], tgt, "target", ts, slip=False)
            if r is None and square_off:
                r = self.close(t["id"], ltp, "square_off", ts)
            if r is None:
                db.update_row(db.paper_trades, t["id"], last_price=float(ltp))
            else:
                out.append(r)
        return out

    def square_off(self, symbol: str, price: float | None = None) -> list[dict]:
        out = []
        for t in self.open_trades():
            if t["symbol"] == symbol:
                out.append(self.close(t["id"], price or t["last_price"] or t["entry_price"], "manual"))
        return out

    def summary(self, quotes: dict[str, dict] | None = None) -> dict:
        w = self.wallet.get()
        opens = self.open_trades()
        mtm = 0.0
        for t in opens:
            ltp = ((quotes or {}).get(t["symbol"]) or {}).get("ltp") or t["last_price"] or t["entry_price"]
            t["ltp"] = ltp
            t["mtm"] = round((ltp - t["entry_price"]) * t["qty"] * (1 if t["side"] == "BUY" else -1), 2)
            mtm += t["mtm"]
        closed = db.fetch(db.paper_trades, db.paper_trades.c.status == "closed")
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        todays = [t for t in closed if t["exit_ts"] and t["exit_ts"] >= today]
        wins = [t for t in closed if (t["net_pnl"] or 0) > 0]
        return {
            "balance": round(w["balance"], 2), "starting_balance": round(w["starting_balance"], 2),
            "blocked_margin": self.wallet.blocked(), "available": self.wallet.available(),
            "open_mtm": round(mtm, 2), "equity": round(w["balance"] + mtm, 2),
            "total_pnl": round(w["balance"] - w["starting_balance"] + mtm, 2),
            "today_realized": round(sum(t["net_pnl"] or 0 for t in todays), 2), "today_trades": len(todays),
            "closed_trades": len(closed), "win_rate": round(len(wins) / len(closed) * 100, 1) if closed else None,
            "total_costs": round(sum(t["costs"] or 0 for t in closed), 2),
            "open_positions": opens, "leverage": self.leverage, "slippage_bps": self.slippage_bps,
            "real_orders": "LOCKED" if not settings.live_orders_allowed else "ENABLED",
        }
