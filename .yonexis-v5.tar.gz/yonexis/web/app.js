// YONEXIS dashboard (vanilla JS, no build step)
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
let TOKEN = localStorage.getItem("yx_token") || "";
if (!TOKEN) { TOKEN = prompt("Admin token (ADMIN_TOKEN from .env)") || ""; localStorage.setItem("yx_token", TOKEN); }

async function api(path, opts = {}) {
  const o = { ...opts, headers: { "X-Admin-Token": TOKEN, ...(opts.headers || {}) } };
  if (opts.json !== undefined) { o.body = JSON.stringify(opts.json); o.headers["Content-Type"] = "application/json"; o.method = o.method || "POST"; }
  const r = await fetch(path, o);
  if (r.status === 401) { localStorage.removeItem("yx_token"); alert("Wrong admin token"); location.reload(); }
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("json") ? await r.json() : await r.text();
  if (!r.ok) throw new Error(typeof body === "string" ? body : JSON.stringify(body.detail ?? body, null, 1));
  return body;
}
const fmt = (n, d = 2) => n == null || isNaN(n) ? "—" : Number(n).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d });
const inr = (n, d = 0) => n == null || isNaN(n) ? "—" : (n < 0 ? "-₹" : "₹") + fmt(Math.abs(n), d);
const cls = n => n > 0 ? "green" : n < 0 ? "red" : "";
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const syms = id => $(id).value.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);
const pj = (id) => { const v = $(id).value.trim(); return v ? JSON.parse(v) : {}; };

// ---------------------------------------------------------------- tabs
$$("#tabs button").forEach(b => b.onclick = () => {
  $$("#tabs button").forEach(x => x.classList.toggle("on", x === b));
  $$(".tab").forEach(t => t.classList.toggle("on", t.id === "tab-" + b.dataset.tab));
  const loaders = { wallet: loadWallet, models: loadModelsTab, data: () => { loadInventory(); loadUpstox(); }, feedback: loadFeedback, risk: loadRisk, backtest: loadStrategySelects, import: loadStrategySelects };
  loaders[b.dataset.tab]?.();
});

async function health() {
  try {
    const h = await api("/api/health");
    const f = window._feed;
    const fdot = !f ? (h.connector === "simulated" ? "a" : "") : f.status === "connected" ? "g" : f.status === "waiting_for_login" ? "r" : "a";
    let wl = ""; try { const w = await api("/api/wallet"); wl = `<span class="chip">Demo wallet <b>${inr(w.equity)}</b></span>`; } catch (e) {}
    $("#health").innerHTML =
      (h.real_orders === "LOCKED" ? `<span class="chip" title="No order can reach a broker">🔒 <b>Paper</b></span>` : `<span class="chip red">REAL ORDERS ON</span>`) + wl +
      `<span class="chip" title="${esc(f ? f.status + (f.error ? ": " + f.error : "") : h.connector)}"><span class="dot ${fdot}"></span>${h.connector}${f ? " · " + f.status.replaceAll("_", " ") : ""}</span>` +
      `<span class="chip" title="${esc(h.llm.model)}"><span class="dot ${h.llm.ok ? "g" : "r"}"></span>AI ${h.llm.ok ? "ready" : "offline"}</span>`;
  } catch (e) { $("#health").innerHTML = `<span class="chip"><span class="dot r"></span>API offline</span>`; }
}

// ---------------------------------------------------------------- toasts + error reporting
function toast(html, kind = "", ms = 6000) {
  const t = document.createElement("div"); t.className = "toast " + kind; t.innerHTML = html;
  $("#toasts").appendChild(t); setTimeout(() => t.remove(), ms);
}
window.addEventListener("error", e => { try { fetch("/api/client-log", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: String(e.message), where: `${e.filename}:${e.lineno}` }) }); } catch (_) {} });
window.addEventListener("unhandledrejection", e => { try { fetch("/api/client-log", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: String(e.reason && e.reason.message || e.reason), where: "promise" }) }); } catch (_) {} });
// Coming back from the Upstox login page restores a frozen copy of this page; reload it so the live socket reconnects.
window.addEventListener("pageshow", e => { if (e.persisted) location.reload(); });

// ---------------------------------------------------------------- live
let selected = null, chart, series, zoneLines = [], statusRows = {};
function initChart() {
  chart = LightweightCharts.createChart($("#chart"), {
    layout: { background: { color: "#0d1424" }, textColor: "#8a98b4" },
    grid: { vertLines: { color: "#131d33" }, horzLines: { color: "#131d33" } },
    timeScale: { timeVisible: true, secondsVisible: false, borderColor: "#1e2a44" }, rightPriceScale: { borderColor: "#1e2a44" },
    autoSize: true,
  });
  series = chart.addCandlestickSeries({ upColor: "#22c55e", downColor: "#ef4444", borderVisible: false, wickUpColor: "#22c55e", wickDownColor: "#ef4444" });
}
const toUnix = ts => Math.floor(new Date(ts.replace(" ", "T") + "Z").getTime() / 1000);

let histMode = null;   // null = live, else {start, end, interval}
function paint(rows, zone, sigs) {
  series.setData(rows.map(r => ({ time: toUnix(r.ts), open: r.open, high: r.high, low: r.low, close: r.close })));
  zoneLines.forEach(l => series.removePriceLine(l)); zoneLines = [];
  if (zone && zone.zone_high) {
    zoneLines.push(series.createPriceLine({ price: zone.zone_high, color: "#ef4444", lineStyle: 2, lineWidth: 1, title: "zone high" }));
    zoneLines.push(series.createPriceLine({ price: zone.zone_low, color: "#ef4444", lineStyle: 2, lineWidth: 1, title: "zone low" }));
  }
  series.setMarkers((sigs || []).map(s => ({ time: toUnix(String(s.ts).replace("T", " ")), position: s.side === "BUY" ? "belowBar" : "aboveBar",
    color: s.side === "BUY" ? "#22c55e" : "#ef4444", shape: s.side === "BUY" ? "arrowUp" : "arrowDown", text: s.side })).sort((a, b) => a.time - b.time));
  chart.timeScale().fitContent();
}
async function drawChart(sym) {
  if (histMode) return drawHistory(sym);
  const rows = await api(`/api/candles?symbol=${sym}&live_view=true`);
  const day = (rows.at(-1)?.ts || "").slice(0, 10);
  paint(rows, statusRows[sym], (window._signals || []).filter(s => s.symbol === sym && s.ts.slice(0, 10) === day));
  $("#ch-src").textContent = day ? `showing session ${day}` : "";
}
async function drawHistory(sym) {
  const { start, end, interval } = histMode;
  $("#ch-src").textContent = "loading...";
  try {
    const r = await api(`/api/chart?symbol=${sym}&start=${start}&end=${end}&interval=${interval}`);
    paint(r.candles, r.zone, r.signals);
    $("#ch-src").textContent = `${sym} ${start}${end !== start ? " to " + end : ""} · ${interval} · ${r.candles.length} candles · source: ${r.source}`;
  } catch (e) { series.setData([]); $("#ch-src").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
}
const isoDay = d => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
function prevWeekday(d) { const x = new Date(d); do { x.setDate(x.getDate() - 1); } while (x.getDay() === 0 || x.getDay() === 6); return x; }
$("#ch-end").value = isoDay(new Date()); $("#ch-start").value = isoDay(prevWeekday(new Date()));
$("#ch-go").onclick = () => { histMode = { start: $("#ch-start").value, end: $("#ch-end").value || $("#ch-start").value, interval: $("#ch-int").value }; $("#ch-live").classList.remove("on"); drawChart(selected); };
$("#ch-live").onclick = () => { histMode = null; $("#ch-live").classList.add("on"); drawChart(selected); };
$$(".chart-bar [data-days]").forEach(b => b.onclick = () => {
  const n = +b.dataset.days, today = new Date();
  if (n === 1) { const d = isoDay(prevWeekday(today)); $("#ch-start").value = d; $("#ch-end").value = d; }
  else { const s = new Date(today); s.setDate(s.getDate() - n); $("#ch-start").value = isoDay(s); $("#ch-end").value = isoDay(today); if ($("#ch-int").value === "1m") $("#ch-int").value = n > 5 ? "15m" : "5m"; }
  $("#ch-go").click();
});

let lastPx = {};
function renderWatch(rows, simDay) {
  statusRows = rows;
  const q = ($("#w-search").value || "").trim().toUpperCase(), sort = $("#w-sort").value;
  let list = Object.entries(rows).filter(([s]) => !q || s.includes(q));
  if (sort === "chg") list.sort((a, b) => (b[1].change_pct ?? -1e9) - (a[1].change_pct ?? -1e9));
  else if (sort === "name") list.sort((a, b) => a[0].localeCompare(b[0]));
  else if (sort === "sig") list.sort((a, b) => (b[1].signal ? 1 : 0) - (a[1].signal ? 1 : 0));
  const tb = $("#watch tbody"); tb.innerHTML = "";
  list.forEach(([sym, r]) => {
    const stc = r.status === "ABOVE" ? "green" : r.status === "BELOW" ? "red" : "amber";
    const arrow = r.status === "ABOVE" ? "▲ " : r.status === "BELOW" ? "▼ " : "";
    const sig = r.signal ? `<span class="pill ${r.signal.toLowerCase()}">${r.signal}</span>` : `<span class="muted">–</span>`;
    const tr = document.createElement("tr");
    if (sym === selected) tr.className = "sel";
    const prev = lastPx[sym]; lastPx[sym] = r.price;
    const flash = prev != null && r.price !== prev ? (r.price > prev ? "flash-up" : "flash-dn") : "";
    tr.innerHTML = `<td><b class="${sym === selected ? "amber" : ""}">${sym}</b></td><td class="r ${flash}">${fmt(r.price)}</td>
      <td class="r ${cls(r.change_pct)}">${r.change_pct == null ? "" : (r.change_pct > 0 ? "+" : "") + fmt(r.change_pct) + "%"}</td>
      <td class="${stc} xs">${arrow}${(r.status || "").replace("WAITING", "waiting")}</td><td>${sig}</td>
      <td><button class="rm" title="Remove from watchlist">×</button></td>`;
    tr.querySelector(".rm").onclick = ev => { ev.stopPropagation(); removeSymbol(sym); };
    tr.onclick = () => { selected = sym; renderWatch(statusRows, simDay); renderCards(simDay); drawChart(sym); };
    tb.appendChild(tr);
  });
  if (!selected && Object.keys(rows).length) { selected = Object.keys(rows)[0]; drawChart(selected); }
  renderCards(simDay);
}
$("#w-search").oninput = () => renderWatch(statusRows, window._simDay);

// ---- add / remove watchlist symbols
let suggTimer = null, suggIdx = -1;
async function loadWatchNote() {
  try {
    const w = await api("/api/watchlist");
    window._watch = w.symbols;
    $("#wl-note").innerHTML = `${w.symbols.length}/${w.max} symbols · calls come from: ${w.strategies_making_calls.length ? w.strategies_making_calls.map(esc).join(", ") : '<span class="amber">no strategy in paper status</span>'}`;
  } catch (e) {}
}
async function addSymbol(sym) {
  $("#wl-sugg").hidden = true; $("#wl-add").value = "";
  toast(`Adding <b>${esc(sym)}</b>… loading its history`, "", 3000);
  try {
    await api("/api/watchlist", { json: { symbol: sym } });
    toast(`<b>${esc(sym)}</b> added — it appears in the list within a few seconds`, "buy");
    selected = sym; loadWatchNote();
  } catch (e) { toast(esc(e.message), "err"); }
}
async function removeSymbol(sym) {
  if (!confirm(`Remove ${sym} from the watchlist? No new calls will be made on it.`)) return;
  try { await api(`/api/watchlist/${encodeURIComponent(sym)}`, { method: "DELETE" }); delete statusRows[sym]; if (selected === sym) selected = null; renderWatch(statusRows, window._simDay); loadWatchNote(); }
  catch (e) { toast(esc(e.message), "err"); }
}
$("#wl-add").oninput = () => {
  clearTimeout(suggTimer);
  const q = $("#wl-add").value.trim();
  if (q.length < 2) { $("#wl-sugg").hidden = true; return; }
  suggTimer = setTimeout(async () => {
    try {
      const rows = await api(`/api/upstox/search?q=${encodeURIComponent(q)}`);
      const have = new Set(window._watch || Object.keys(statusRows));
      suggIdx = -1;
      $("#wl-sugg").innerHTML = rows.length ? rows.map(r => `<div data-s="${esc(r.symbol)}"><b>${esc(r.symbol)}</b><small>${esc(r.name || "")}</small>${have.has(r.symbol) ? '<small class="green">added</small>' : ""}</div>`).join("")
        : `<div class="muted">No NSE equity matches “${esc(q)}”. Press Enter to try “${esc(q.toUpperCase())}” anyway.</div>`;
      $("#wl-sugg").hidden = false;
      $$("#wl-sugg [data-s]").forEach(d => d.onmousedown = () => addSymbol(d.dataset.s));
    } catch (e) { $("#wl-sugg").innerHTML = `<div class="red">${esc(e.message)}</div>`; $("#wl-sugg").hidden = false; }
  }, 200);
};
$("#wl-add").onkeydown = e => {
  const items = $$("#wl-sugg [data-s]");
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault(); suggIdx = Math.max(0, Math.min(items.length - 1, suggIdx + (e.key === "ArrowDown" ? 1 : -1)));
    items.forEach((d, i) => d.classList.toggle("hi", i === suggIdx));
  } else if (e.key === "Enter") { const pick = items[suggIdx] || items[0]; addSymbol(pick ? pick.dataset.s : $("#wl-add").value.trim().toUpperCase()); }
  else if (e.key === "Escape") $("#wl-sugg").hidden = true;
};
$("#wl-add").onblur = () => setTimeout(() => $("#wl-sugg").hidden = true, 150);
$("#w-sort").onchange = () => renderWatch(statusRows, window._simDay);

function renderCards(simDay) {
  const r = statusRows[selected]; if (!r) return;
  $("#c-sym").textContent = selected;
  const fm = r.forming ? `forming ${String(r.forming.ts).slice(11, 16)}` : "";
  $("#c-day").textContent = simDay ? `simulated session ${simDay}` : `${(r.tick_ts || r.ts || "").slice(0, 16)} ${fm}`;
  $("#c-zone").textContent = r.zone_size ? `${fmt(r.zone_size)} (${fmt(r.zone_pct)}%)${r.zone_provisional ? " · forming" : ""}` : "waiting for first red candle";
  $("#c-price").textContent = fmt(r.price);
  $("#c-chg").innerHTML = r.change_pct == null ? "" : `<span class="${cls(r.change_pct)}">${r.change_pct > 0 ? "+" : ""}${fmt(r.change_pct)}%</span>`;
  const sc = r.status === "ABOVE" ? "green" : r.status === "BELOW" ? "red" : "amber";
  $("#c-status").innerHTML = `<span class="${sc}">${r.status === "ABOVE" || r.status === "BELOW" ? r.status + " ZONE" : (r.status || "—")}</span>`;
  $("#c-signal").innerHTML = r.signal ? `<span class="${r.signal === "BUY" ? "green" : "red"}">${r.signal}</span>` : "—";
}

let callsFilter = "today";
$$("#calls-filter button").forEach(b => b.onclick = () => { callsFilter = b.dataset.f; $$("#calls-filter button").forEach(x => x.classList.toggle("on", x === b)); loadCalls(); });
async function loadCalls() {
  const rows = await api("/api/signals?limit=200");
  window._signals = rows;
  const today = isoDay(new Date());
  const shown = rows.filter(s => callsFilter === "all" ? true : callsFilter === "review" ? !s.feedback : s.ts.slice(0, 10) === today);
  const tb = $("#calls tbody"); tb.innerHTML = "";
  if (!shown.length) tb.innerHTML = `<tr><td colspan="10" class="muted">${callsFilter === "today" ? "No calls yet today. Calls appear here when a strategy in paper status triggers." : "Nothing to show."}</td></tr>`;
  shown.forEach(s => {
    const sc = s.score == null ? `<span class="muted xs">no model</span>` : `<b class="${s.score >= .5 ? "green" : "red"}">${fmt(s.score * 100, 0)}%</b>`;
    const out = s.outcome_pnl == null ? `<span class="muted">open</span>` : `<span class="${cls(s.outcome_pnl)}">${inr(s.outcome_pnl)}</span> <span class="muted xs">${esc(s.outcome || "")}</span>`;
    const fb = s.feedback ? `<span class="muted xs">${s.feedback.action}${s.feedback.remark ? ": " + esc(s.feedback.remark).slice(0, 40) : ""}</span>` :
      `<button class="sm ib ok" data-a="agree" title="Agree">✓</button> <button class="sm ib no" data-a="reject" title="Reject">✗</button> <button class="sm ib" data-a="modify" title="Modify SL / target">✎</button> <button class="sm ib" data-a="skip" title="Skip">Skip</button>`;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td class="mono">${s.ts.slice(5, 16).replace("T", " ")}</td><td><b>${s.symbol}</b></td><td><span class="pill ${s.side.toLowerCase()}">${s.side}</span></td>
      <td class="r">${fmt(s.price)}</td><td class="r">${fmt(s.stop_loss)}</td><td class="r">${fmt(s.target)}</td><td>${sc}</td><td class="muted xs">${esc(s.status)}</td><td>${out}</td><td>${fb}</td>`;
    $$("button", tr).forEach(b => b.onclick = () => feedbackDialog(s, b.dataset.a));
    tb.appendChild(tr);
  });
}

function feedbackDialog(s, action) {
  const d = $("#dlg");
  $("#dlg-body").innerHTML = `<div class="panel-h">${action.toUpperCase()} · ${s.side} ${s.symbol} @ ${fmt(s.price)}</div>
    <p class="muted">${esc(s.reason)}</p>
    ${action === "modify" ? `<div class="form"><label>New SL <input id="fb-sl" type="number" step="0.05" value="${s.stop_loss}"></label><label>New target <input id="fb-tg" type="number" step="0.05" value="${s.target ?? ""}"></label></div>` : ""}
    <label class="muted">Remark (why?) — this becomes training data<textarea id="fb-remark" rows="3" placeholder="e.g. results tomorrow, resistance at 2700, volume fake"></textarea></label>`;
  d.showModal();
  d.onclose = async () => {
    if (d.returnValue !== "ok") return;
    const body = { action, remark: $("#fb-remark").value };
    if (action === "modify") { body.new_sl = parseFloat($("#fb-sl").value); body.new_target = parseFloat($("#fb-tg").value); }
    try { await api(`/api/signals/${s.id}/feedback`, { json: body }); loadCalls(); } catch (e) { alert(e.message); }
  };
}

function updateForming(r) {
  if (histMode || !r || !r.forming) return;
  const f = r.forming;
  try { series.update({ time: toUnix(String(f.ts)), open: f.open, high: f.high, low: Math.min(f.low, f.close), close: f.close }); } catch (e) {}
}
function connectWS() {
  const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws/live?token=${encodeURIComponent(TOKEN)}`);
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.type === "status") {
      const prev = statusRows[selected] || {};
      window._simDay = m.sim_day;
      if (m.feed) { window._feed = m.feed; liveBanner(m.feed, m.rows); }
      renderWatch(m.rows, m.sim_day);
      const r = m.rows[selected] || {};
      $("#clock").textContent = (r.tick_ts || r.ts || "").slice(11, 19);
      const newSession = (r.forming && !prev.forming) || String(r.last_closed || "").slice(0, 10) !== String(prev.last_closed || "").slice(0, 10);
      if (selected && !histMode && (r.last_closed !== prev.last_closed || newSession)) drawChart(selected).then(() => updateForming(r));
      else updateForming(r);
    } else if (m.type === "signal") {
      toast(`<b>${m.side} ${m.symbol}</b> @ ${fmt(m.price)}<div class="muted xs">${esc(m.reason || "")}${m.order ? " · paper filled " + m.order.qty : ""}</div>`, m.side.toLowerCase());
      loadCalls(); if ($("#tab-wallet").classList.contains("on")) loadWallet();
    } else if (m.type === "paper_exit") {
      toast(`Paper exit <b>${m.symbol}</b> · ${esc(m.exit || "")}<div class="${cls(m.net_pnl)}">${inr(m.net_pnl)}</div>`, m.net_pnl >= 0 ? "buy" : "sell");
      loadCalls(); if ($("#tab-wallet").classList.contains("on")) loadWallet();
    }
  };
  ws.onclose = () => setTimeout(connectWS, 3000);
}

// ---------------------------------------------------------------- backtest
async function loadStrategySelects() {
  const rows = await api("/api/strategies");
  const latest = {}; rows.forEach(r => latest[r.name] = r);
  const opts = Object.values(latest).map(r => `<option value="${r.name}">${r.name} (v${r.version}, ${r.status})</option>`).join("");
  ["#bt-strategy", "#par-strategy", "#tm-strategy"].forEach(id => { const v = $(id).value; $(id).innerHTML = opts; if (v) $(id).value = v; });
}

function metricsKV(m) {
  if (!m || !m.trades) return `<p class="muted">No trades.</p>`;
  const items = [["Trades", m.trades], ["Net P&L (after costs)", `<span class="${cls(m.net_pnl)}">${inr(m.net_pnl)}</span>`],
    ["Costs paid", `${inr(m.total_costs)}`], ["Win rate", fmt(m.win_rate) + "%"], ["Avg win / loss", `${inr(m.avg_win)} / ${inr(m.avg_loss)}`],
    ["Profit factor", fmt(m.profit_factor, 2)], ["Sharpe", fmt(m.sharpe, 2)], ["Max drawdown", `${inr(m.max_drawdown)} (${fmt(m.max_drawdown_pct)}%)`],
    ["Trades / month", fmt(m.trades_per_month, 1)], ["Period", `${(m.start || "").slice(0, 10)} → ${(m.end || "").slice(0, 10)}`]];
  return `<div class="kv">${items.map(([k, v]) => `<div>${k}</div><div>${v}</div>`).join("")}</div>`;
}

function equityChart(el, daily) {
  if (!daily || !daily.length) return;
  const c = LightweightCharts.createChart(el, { height: 220, autoSize: true, layout: { background: { color: "#0d1424" }, textColor: "#8a98b4" },
    grid: { vertLines: { color: "#131d33" }, horzLines: { color: "#131d33" } } });
  c.addAreaSeries({ lineColor: "#38bdf8", topColor: "rgba(56,189,248,.25)", bottomColor: "rgba(56,189,248,0)" })
    .setData(daily.map(d => ({ time: d.date.slice(0, 10), value: d.equity })));
  c.timeScale().fitContent();
}

function evaluationHTML(ev) {
  const v = (ev.verdict || "").toLowerCase();
  const checks = Object.entries(ev.checks || {}).map(([k, ok]) => `<span class="${ok ? "ok" : "no"}">${ok ? "✓" : "✗"} ${k.replaceAll("_", " ")}</span>`).join("");
  const mc = ev.monte_carlo || {}, wf = ev.walk_forward || {}, st = ev.stress || {};
  const regimes = Object.entries(ev.regimes || {}).map(([r, x]) => `<tr><td>${r}</td><td class="r">${x.trades}</td><td class="r ${cls(x.net_pnl)}">${fmt(x.net_pnl, 0)}</td><td class="r">${fmt(x.win_rate)}%</td></tr>`).join("");
  const stressRows = ["costs_x2", "slippage_x2", "slippage_x4"].map(k => st[k] ? `<tr><td>${k.replace("_", " ")}</td><td class="r ${cls(st[k].net_pnl)}">${fmt(st[k].net_pnl, 0)}</td></tr>` : "").join("")
    + Object.entries(st.historical_windows || {}).filter(([k]) => k !== "note").map(([k, x]) => `<tr><td>${k}</td><td class="r ${cls(x.net_pnl)}">${fmt(x.net_pnl, 0)}</td></tr>`).join("");
  return `<div class="panel"><div class="panel-h"><span>Verdict <span class="pill ${v}">${ev.verdict}</span> · ${ev.score} checks passed</span><span class="muted">deflated Sharpe ${fmt(ev.deflated_sharpe_prob, 3)} · ${ev.n_trials} variants tried</span></div><div class="checks">${checks}</div></div>
  <div class="grid2">
    <div class="panel"><div class="panel-h">Development period</div>${metricsKV(ev.development)}</div>
    <div class="panel"><div class="panel-h">Locked holdout (never seen in tuning)</div>${metricsKV(ev.holdout)}</div>
    <div class="panel"><div class="panel-h">Monte Carlo (${mc.n_sims || 0} runs)</div><div class="kv">
      <div>Net P&L 5th / 50th / 95th pct</div><div>${inr(mc.net_pnl_p5)} / ${inr(mc.net_pnl_p50)} / ${inr(mc.net_pnl_p95)}</div>
      <div>Probability of loss</div><div>${fmt(mc.prob_loss)}%</div><div>95% worst drawdown</div><div>${inr(mc.max_dd_p95_worst)}</div></div></div>
    <div class="panel"><div class="panel-h">Walk-forward (out of sample)</div>${wf.oos_metrics ? metricsKV(wf.oos_metrics) + `<p class="muted">${wf.pct_profitable_folds}% of ${wf.folds.length} folds profitable</p>` : `<p class="muted">${wf.note || "No parameter grid given."}</p>`}</div>
    <div class="panel"><div class="panel-h">Stress tests (net P&L)</div><table class="tbl">${stressRows}</table></div>
    <div class="panel"><div class="panel-h">By market regime</div><table class="tbl"><tr><th>Regime</th><th class="r">Trades</th><th class="r">Net P&L</th><th class="r">Win %</th></tr>${regimes}</table>
      <p class="muted">Parameter sensitivity: ${ev.sensitivity?.fragile ? '<b class="red">fragile</b>' : '<span class="green">stable</span>'} (worst ±10% move: ${inr(ev.sensitivity?.worst_net_pnl)})</p></div>
  </div>
  ${ev.report ? `<div class="panel"><div class="panel-h">Report agent</div><div class="prose">${esc(ev.report)}</div></div>` : ""}
  ${ev.critic ? `<div class="panel"><div class="panel-h">Critic agent (red team)</div><div class="prose">${esc(ev.critic)}</div></div>` : ""}`;
}

async function pollJob(jid, onLog) {
  while (true) {
    const j = await api(`/api/jobs/${jid}`);
    onLog?.(j);
    if (j.status !== "running") return j;
    await new Promise(r => setTimeout(r, 1500));
  }
}

function btBody() {
  return { strategy: $("#bt-strategy").value, symbols: syms("#bt-symbols"), interval: $("#bt-interval").value, start: $("#bt-start").value,
    end: $("#bt-end").value, source: $("#bt-source").value, params: pj("#bt-params"),
    param_space: $("#bt-space").value.trim() ? JSON.parse($("#bt-space").value) : null,
    baseline_net_pnl: $("#bt-baseline").value ? parseFloat($("#bt-baseline").value) : null };
}
$("#bt-quick").onclick = async () => {
  $("#bt-out").innerHTML = `<div class="panel muted">Running…</div>`;
  try {
    const r = await api("/api/backtests/quick", { json: btBody() });
    $("#bt-out").innerHTML = `<div class="grid2"><div class="panel"><div class="panel-h">Results</div>${metricsKV(r.metrics)}</div><div class="panel"><div class="panel-h">Equity</div><div id="eq"></div></div></div>
      <div class="panel"><div class="panel-h">Trades (first 200)</div><table class="tbl"><tr><th>Symbol</th><th>Side</th><th>Entry</th><th class="r">Price</th><th>Exit</th><th class="r">Price</th><th>Why</th><th class="r">Net P&L</th></tr>
      ${r.trades.slice(0, 200).map(t => `<tr><td>${t.symbol}</td><td>${t.side}</td><td>${t.entry_ts.slice(0, 16)}</td><td class="r">${fmt(t.entry)}</td><td>${t.exit_ts.slice(11, 16)}</td><td class="r">${fmt(t.exit)}</td><td class="muted">${t.exit_reason}</td><td class="r ${cls(t.net_pnl)}">${fmt(t.net_pnl, 0)}</td></tr>`).join("")}</table></div>`;
    equityChart($("#eq"), r.daily);
  } catch (e) { $("#bt-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};
$("#bt-full").onclick = async () => {
  $("#bt-out").innerHTML = `<div class="panel"><span class="muted">Full evaluation running: walk-forward, Monte Carlo, sensitivity, stress, regimes, holdout… this can take a few minutes.</span></div>`;
  try {
    const { job_id } = await api("/api/backtests/full", { json: btBody() });
    const j = await pollJob(job_id);
    if (j.status === "error") throw new Error(j.error);
    $("#bt-out").innerHTML = evaluationHTML(j.result);
  } catch (e) { $("#bt-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- AI builder
$("#ai-spec").onclick = async () => {
  $("#ai-spec-status").textContent = "Spec agent is reading your idea…";
  try {
    const card = await api("/api/agents/spec", { json: { prompt: $("#ai-prompt").value } });
    $("#ai-card").value = JSON.stringify(card, null, 2);
    $("#ai-questions").innerHTML = (card.questions || []).map(q => `<div class="q">❓ ${esc(q)}</div>`).join("") +
      ((card.questions || []).length ? `<p class="muted">Answer these by editing the card below (or add the answer to your idea and create the card again).</p>` : "");
    $("#ai-card-panel").hidden = false; $("#ai-spec-status").textContent = "";
  } catch (e) { $("#ai-spec-status").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
};
$("#ai-build").onclick = async () => {
  let spec; try { spec = JSON.parse($("#ai-card").value); } catch { return alert("Rule card is not valid JSON"); }
  $("#ai-progress").hidden = false; $("#ai-log").textContent = ""; $("#ai-out").innerHTML = "";
  try {
    const { job_id } = await api("/api/agents/build", { json: { spec, symbols: syms("#ai-symbols"), start: $("#ai-start").value, end: $("#ai-end").value,
      source: $("#ai-source").value, baseline_net_pnl: $("#ai-baseline").value ? parseFloat($("#ai-baseline").value) : null } });
    const j = await pollJob(job_id, j => { $("#ai-log").textContent = j.log.map(l => `[${l.t}s] ${l.stage} ${JSON.stringify(Object.fromEntries(Object.entries(l).filter(([k]) => !["t", "stage"].includes(k))))}`).join("\n"); });
    if (j.status === "error") throw new Error(j.error + "\n" + (j.trace || ""));
    const r = j.result;
    if (!r.ok) { $("#ai-out").innerHTML = `<div class="panel"><div class="panel-h red">Stopped at: ${r.stage}</div><pre class="log">${esc(JSON.stringify(r.problems || r.error, null, 2))}</pre><pre class="log">${esc(r.code)}</pre></div>`; return; }
    $("#ai-out").innerHTML = `<div class="panel"><div class="panel-h">Saved as <b>${r.saved?.name} v${r.saved?.version}</b> (candidate). Approve it in Strategies &amp; Models.</div></div>` +
      evaluationHTML({ ...r.evaluation, critic: r.critic, report: r.report }) +
      `<div class="panel"><div class="panel-h">Generated code</div><pre class="log">${esc(r.code)}</pre></div>`;
  } catch (e) { $("#ai-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- import & parity
$("#imp-convert").onclick = async () => {
  $("#imp-status").textContent = "Converter agent working…"; $("#imp-out").innerHTML = "";
  try {
    const { job_id } = await api("/api/import/convert", { json: { source: $("#imp-src").value, language: $("#imp-lang").value, notes: $("#imp-notes").value, name: $("#imp-name").value || null } });
    const j = await pollJob(job_id, j => $("#imp-status").textContent = `stage: ${j.stage}`);
    if (j.status === "error") throw new Error(j.error);
    const r = j.result;
    $("#imp-status").textContent = r.saved ? `Saved as ${r.saved.name} v${r.saved.version}. Now run a parity check below.` : "Not saved: review found problems.";
    $("#imp-out").innerHTML = `<pre class="log">${esc(JSON.stringify({ approved: r.review.approved, issues: r.review.issues, static: r.review.static_check }, null, 2))}</pre><pre class="log">${esc(r.code)}</pre>`;
    loadStrategySelects();
  } catch (e) { $("#imp-status").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
};
$("#par-run").onclick = async () => {
  const f = $("#par-file").files[0]; if (!f) return alert("Choose the admin's trades file");
  const fd = new FormData(); fd.append("file", f); fd.append("strategy", $("#par-strategy").value); fd.append("interval", $("#par-interval").value); fd.append("params", $("#par-params").value || "{}");
  $("#par-out").innerHTML = `<p class="muted">Comparing trade by trade…</p>`;
  try {
    const r = await api("/api/import/parity", { method: "POST", body: fd });
    $("#par-out").innerHTML = `<div class="panel-h">Verdict: <span class="pill ${r.verdict === "PARITY" ? "pass" : r.verdict === "CLOSE" ? "review" : "fail"}">${r.verdict}</span> ${fmt(r.match_rate_pct)}% matched</div>
      <div class="kv"><div>Admin trades</div><div>${r.admin_trades}</div><div>Our trades</div><div>${r.our_trades}</div><div>Matched</div><div>${r.matched}</div><div>Shifted</div><div>${r.shifted}</div><div>Missing</div><div>${r.missing}</div><div>Extra</div><div>${r.extra}</div>
      ${r.admin_net_pnl != null ? `<div>Admin net P&L</div><div>${inr(r.admin_net_pnl)}</div><div>Our net P&L</div><div>${inr(r.our_net_pnl)}</div>` : ""}</div>
      <p>${r.likely_causes.map(esc).join("<br>")}</p><pre class="log">${esc(JSON.stringify(r.examples, null, 1))}</pre>`;
  } catch (e) { $("#par-out").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- data
const today = new Date(); $("#df-end").value = today.toISOString().slice(0, 10);
$("#df-start").value = new Date(today - 55 * 864e5).toISOString().slice(0, 10);
$("#df-go").onclick = async () => {
  $("#df-out").textContent = "Fetching…";
  try { const r = await api("/api/data/fetch", { json: { symbols: syms("#df-symbols"), source: $("#df-source").value, interval: $("#df-interval").value, start: $("#df-start").value, end: $("#df-end").value } });
    $("#df-out").textContent = JSON.stringify(r, null, 2); loadInventory(); } catch (e) { $("#df-out").textContent = e.message; }
};
$("#up-preview").onclick = async () => {
  const f = $("#up-file").files[0]; if (!f) return; const fd = new FormData(); fd.append("file", f);
  try { const r = await api("/api/data/upload/preview", { method: "POST", body: fd }); $("#up-out").textContent = JSON.stringify(r, null, 2);
    $("#up-kind").value = r.kind_guess === "trades" ? "trades" : "candles"; } catch (e) { $("#up-out").textContent = e.message; }
};
$("#up-go").onclick = async () => {
  const f = $("#up-file").files[0]; if (!f) return; const fd = new FormData();
  fd.append("file", f); fd.append("kind", $("#up-kind").value); fd.append("symbol", $("#up-symbol").value); fd.append("interval", $("#up-interval").value); fd.append("mapping", $("#up-mapping").value || "{}");
  $("#up-out").textContent = "Validating…";
  try { const r = await api("/api/data/upload", { method: "POST", body: fd }); $("#up-out").textContent = JSON.stringify(r, null, 2); loadInventory(); } catch (e) { $("#up-out").textContent = e.message; }
};
async function loadInventory() {
  const r = await api("/api/data/inventory");
  $("#inv tbody").innerHTML = r.candles.map(c => `<tr><td>${c.symbol}</td><td>${c.interval}</td><td class="r">${c.n}</td><td>${String(c.first).slice(0, 16)}</td><td>${String(c.last).slice(0, 16)}</td><td class="muted">${c.source}</td></tr>`).join("") || `<tr><td colspan="6" class="muted">No data yet.</td></tr>`;
}

// ---------------------------------------------------------------- models & strategies
const STATUSES = ["candidate", "approved", "paper", "live_small", "live", "retired"];
async function loadModelsTab() {
  await loadStrategySelects();
  const st = await api("/api/strategies");
  $("#strats tbody").innerHTML = st.map(r => `<tr><td><b>${r.name}</b></td><td>${r.version}</td><td class="muted">${r.origin}</td><td class="muted">${String(r.created_at).slice(0, 16)}</td>
    <td><select data-n="${r.name}" data-v="${r.version}">${STATUSES.map(s => `<option ${s === r.status ? "selected" : ""}>${s}</option>`).join("")}</select></td>
    <td><button class="sm" data-code="${r.id}">code</button></td></tr>`).join("");
  $$("#strats select").forEach(s => s.onchange = async () => { try { await api(`/api/strategies/${s.dataset.n}/${s.dataset.v}/status`, { json: { status: s.value } }); } catch (e) { alert(e.message); loadModelsTab(); } });
  $$("#strats [data-code]").forEach(b => b.onclick = () => { const r = st.find(x => x.id == b.dataset.code); $("#dlg-body").innerHTML = `<pre class="log" style="max-height:70vh;min-width:60vw">${esc(r.code)}</pre>`; $("#dlg").showModal(); });
  const ms = await api("/api/models");
  $("#models tbody").innerHTML = ms.map(m => `<tr><td>${m.kind}</td><td>${m.version}</td><td>${m.strategy || "all"}</td><td>${fmt(m.metrics.oos_auc, 3)}</td>
    <td>${fmt((m.metrics.hit_rate_top40pct || 0) * 100, 1)}% / ${fmt((m.metrics.hit_rate_all || 0) * 100, 1)}%</td><td>${m.status}</td>
    <td>${m.status !== "champion" ? `<button class="sm" data-p="${m.id}">promote</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="7" class="muted">No models yet.</td></tr>`;
  $$("#models [data-p]").forEach(b => b.onclick = async () => { await api(`/api/models/${b.dataset.p}/promote`, { method: "POST" }); loadModelsTab(); });
  const bts = await api("/api/backtests");
  $("#bts tbody").innerHTML = bts.map(b => { const s = b.summary || {}; return `<tr><td>${b.id}</td><td>${b.kind}</td><td>${b.strategy} v${b.strategy_version}</td><td>${s.verdict ? `<span class="pill ${s.verdict.toLowerCase()}">${s.verdict}</span>` : ""}</td>
    <td class="r">${s.trades ?? ""}</td><td class="r ${cls(s.net_pnl)}">${fmt(s.net_pnl, 0)}</td><td class="r">${fmt(s.win_rate)}</td><td class="r">${fmt(s.profit_factor)}</td><td class="r">${fmt(s.sharpe)}</td>
    <td>${b.kind === "full" ? `<button class="sm" data-b="${b.id}">open</button>` : ""}</td></tr>`; }).join("");
  $$("#bts [data-b]").forEach(x => x.onclick = async () => { const b = await api(`/api/backtests/${x.dataset.b}`); $$("#tabs button").find(b => b.dataset.tab === "backtest").click(); $("#bt-out").innerHTML = evaluationHTML(b.result); });
}
$("#tm-go").onclick = async () => {
  $("#tm-status").textContent = "Training…";
  try { const { job_id } = await api("/api/models/train-meta", { json: { strategy: $("#tm-strategy").value, symbols: syms("#tm-symbols"), start: $("#tm-start").value, end: $("#tm-end").value, source: $("#tm-source").value } });
    const j = await pollJob(job_id, j => $("#tm-status").textContent = `stage: ${j.stage}`);
    $("#tm-status").textContent = j.status === "done" ? `Trained ${j.result.version}: OOS AUC ${fmt(j.result.metrics.oos_auc, 3)}` : j.error; loadModelsTab();
  } catch (e) { $("#tm-status").textContent = e.message; }
};
$("#ti-go").onclick = async () => { try { const r = await api("/api/models/train-imitation", { method: "POST" }); $("#tm-status").textContent = `Imitation model: OOS AUC ${fmt(r.metrics.oos_auc, 3)}`; loadModelsTab(); } catch (e) { $("#tm-status").textContent = e.message; } };

// ---------------------------------------------------------------- feedback
async function loadFeedback() {
  const s = await api("/api/feedback/scoreboard");
  const card = (k, v, c = "") => `<div class="card"><div class="k">${k}</div><div class="v ${c}">${v}</div></div>`;
  $("#fb-cards").innerHTML = card("Calls with outcome", s.calls_with_outcome) + card("Calls you reviewed", s.calls_with_feedback) +
    card("AI alone P&L", inr(s.ai_alone_pnl), cls(s.ai_alone_pnl)) + card("Your filter P&L", inr(s.admin_filtered_pnl), cls(s.admin_filtered_pnl)) +
    card("Combined P&L", inr(s.combined_pnl), cls(s.combined_pnl)) + card("Your decision accuracy", s.admin_decision_accuracy_pct == null ? "—" : s.admin_decision_accuracy_pct + "%");
  $("#fb-tags tbody").innerHTML = Object.entries(s.by_tag).map(([t, d]) => `<tr><td>${t}</td><td class="r">${d.count}</td><td class="r">${d.rejected}</td><td class="r">${d.admin_right_pct}%</td></tr>`).join("") || `<tr><td colspan="4" class="muted">Add remarks to live calls to see patterns.</td></tr>`;
}
$("#fb-suggest").onclick = async () => {
  $("#fb-sugg").innerHTML = `<p class="muted">Thinking…</p>`;
  try { const r = await api("/api/feedback/suggestions", { method: "POST" });
    $("#fb-sugg").innerHTML = r.suggestions.map(s => `<div class="panel"><b>${esc(s.title)}</b><p class="muted">${esc(s.evidence)}</p><button class="sm" data-p="${esc(s.prompt_for_builder)}">Send to AI Builder</button></div>`).join("") || `<p class="muted">Not enough reviewed calls yet.</p>`;
    $$("#fb-sugg [data-p]").forEach(b => b.onclick = () => { $("#ai-prompt").value = b.dataset.p; $$("#tabs button").find(b => b.dataset.tab === "builder").click(); });
  } catch (e) { $("#fb-sugg").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
};

// ---------------------------------------------------------------- paper wallet
async function loadWallet() {
  try {
    const w = await api("/api/wallet");
    window._wallet = w;
    const card = (k, v, c = "") => `<div class="card"><div class="k">${k}</div><div class="v ${c}">${v}</div></div>`;
    $("#w-cards").innerHTML = card("Equity", inr(w.equity)) + card("Cash balance", inr(w.balance)) + card("Available", inr(w.available)) +
      card("Open MTM", inr(w.open_mtm), cls(w.open_mtm)) + card("Total P&L", inr(w.total_pnl), cls(w.total_pnl)) +
      card("Today realised", inr(w.today_realized), cls(w.today_realized)) + card("Win rate", w.win_rate == null ? "—" : w.win_rate + "%") + card("Costs paid", inr(w.total_costs));
    $("#w-lock").innerHTML = w.real_orders === "LOCKED"
      ? `<b>Paper trading only — real orders are LOCKED.</b> Calls are filled against live Upstox prices and recorded here; nothing is sent to Upstox. Started with ${inr(w.starting_balance)}.`
      : `<b class="red">WARNING: real orders are ENABLED in .env</b>`;
    $("#w-note").textContent = `slippage ${w.slippage_bps} bps · leverage ${w.leverage}x`;
    $("#w-open tbody").innerHTML = w.open_positions.map(t => `<tr><td>${t.id}</td><td>${String(t.entry_ts).slice(5, 16).replace("T", " ")}</td><td><b>${t.symbol}</b></td>
      <td><span class="pill ${t.side.toLowerCase()}">${t.side}</span></td><td class="r">${t.qty}</td><td class="r">${fmt(t.entry_price)}</td><td class="r">${fmt(t.ltp)}</td>
      <td class="r">${fmt(t.stop_loss)}</td><td class="r">${fmt(t.target)}</td><td class="r ${cls(t.mtm)}">${inr(t.mtm)}</td><td class="muted">${esc(t.strategy || "")}</td>
      <td><button class="sm" data-close="${t.id}">Close now</button></td></tr>`).join("") || `<tr><td colspan="12" class="muted">No open paper positions.</td></tr>`;
    $$("#w-open [data-close]").forEach(b => b.onclick = async () => { try { await api(`/api/wallet/close/${b.dataset.close}`, { method: "POST" }); loadWallet(); } catch (e) { alert(e.message); } });
    const tr = await api("/api/wallet/trades");
    $("#w-closed tbody").innerHTML = tr.filter(t => t.status === "closed").map(t => `<tr><td>${t.id}</td><td>${String(t.entry_ts).slice(5, 16).replace("T", " ")}</td><td>${String(t.exit_ts).slice(11, 16)}</td>
      <td><b>${t.symbol}</b></td><td>${t.side}</td><td class="r">${t.qty}</td><td class="r">${fmt(t.entry_price)}</td><td class="r">${fmt(t.exit_price)}</td><td class="muted">${t.exit_reason}</td>
      <td class="r ${cls(t.gross_pnl)}">${inr(t.gross_pnl)}</td><td class="r">${inr(t.costs)}</td><td class="r ${cls(t.net_pnl)}"><b>${inr(t.net_pnl)}</b></td></tr>`).join("") || `<tr><td colspan="12" class="muted">No closed trades yet.</td></tr>`;
    const lg = await api("/api/wallet/ledger");
    $("#w-ledger tbody").innerHTML = lg.map(l => `<tr><td>${String(l.ts).slice(0, 16)}</td><td>${l.kind}</td><td class="r ${cls(l.amount)}">${inr(l.amount)}</td><td class="r">${inr(l.balance_after)}</td><td class="muted">${esc(l.note || "")}</td></tr>`).join("");
  } catch (e) { $("#w-cards").innerHTML = `<pre class="log red">${esc(e.message)}</pre>`; }
}
$("#w-deposit").onclick = async () => { try { await api("/api/wallet/deposit", { json: { amount: parseFloat($("#w-amt").value) } }); loadWallet(); } catch (e) { alert(e.message); } };
$("#w-reset").onclick = async () => { if (!confirm("Reset the demo wallet? Trade history is kept.")) return; try { await api("/api/wallet/reset", { json: { amount: parseFloat($("#w-amt").value) } }); loadWallet(); } catch (e) { alert(e.message); } };
setInterval(() => { if ($("#tab-wallet").classList.contains("on")) loadWallet(); }, 5000);

// ---------------------------------------------------------------- system check
const QUICK_CHECKS = 9;
const scBadge = st => `<span class="pill ${st === "pass" ? "pass" : st === "warn" ? "review" : "fail"}">${st.toUpperCase()}</span>`;
function scRows(results, running) {
  return (results || []).map(x => `<tr><td>${esc(x.check)}</td><td>${scBadge(x.status)}</td><td class="r">${x.seconds}</td>
    <td class="muted" style="white-space:pre-wrap;max-width:760px">${esc(typeof x.detail === "string" ? x.detail : JSON.stringify(x.detail))}</td></tr>`).join("") +
    (running ? `<tr><td>${esc(running)}</td><td><span class="spin"></span> running</td><td></td><td class="muted">${running.startsWith("AI builder") ? "the local model is writing and testing a strategy — this step takes several minutes" : ""}</td></tr>` : "");
}
function renderCheck(r) {
  if (!r || !r.results) return;
  $("#sc-when").textContent = `last run ${r.at} · ${r.summary.pass} pass · ${r.summary.warn} warn · ${r.summary.fail} fail`;
  $("#sc-out tbody").innerHTML = scRows(r.results);
  $("#sc-bar").hidden = true;
}
let scTimer = null;
async function followCheck(jobId, deep) {
  $("#sc-quick").disabled = $("#sc-deep").disabled = true;
  $("#sc-bar").hidden = false;
  let total = QUICK_CHECKS + (deep ? 1 : 0);
  const t0 = Date.now();
  clearInterval(scTimer);
  scTimer = setInterval(() => { $("#sc-elapsed").textContent = `${Math.round((Date.now() - t0) / 1000)}s`; }, 1000);
  try {
    const j = await pollJob(jobId, j => {
      total = (j.log && j.log[0] && j.log[0].total) || total;
      const done = (j.partial || []).length;
      $("#sc-bar > div").style.width = `${Math.min(100, Math.round(done / total * 100))}%`;
      $("#sc-stage").innerHTML = `<span class="spin"></span> ${done}/${total} · ${esc(j.stage)}`;
      $("#sc-out tbody").innerHTML = scRows(j.partial, j.stage);
    });
    if (j.status === "done") { renderCheck(j.result); $("#sc-stage").textContent = "finished"; toast(`System check finished: ${j.result.summary.pass} pass, ${j.result.summary.warn} warn, ${j.result.summary.fail} fail`, j.result.summary.fail ? "err" : "buy"); }
    else { $("#sc-stage").innerHTML = `<span class="red">${esc(j.error || "failed")}</span>`; }
  } catch (e) { $("#sc-stage").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
  clearInterval(scTimer);
  $("#sc-quick").disabled = $("#sc-deep").disabled = false;
}
async function runCheck(deep) {
  $("#sc-out tbody").innerHTML = scRows([], "starting");
  $("#sc-stage").innerHTML = `<span class="spin"></span> starting`;
  try { const { job_id } = await api(`/api/system/check?deep=${deep}`, { method: "POST" }); followCheck(job_id, deep); }
  catch (e) { $("#sc-stage").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
}
$("#sc-quick").onclick = () => runCheck(false);
$("#sc-deep").onclick = () => runCheck(true);
async function resumeCheck() {     // a check started earlier (or in another tab) keeps showing its progress
  try { const j = await api("/api/jobs/latest/system_check"); if (j && j.status === "running") followCheck(j.id, false); } catch (e) {}
}

// ---------------------------------------------------------------- risk
async function loadRisk() {
  if ($("#sc-quick").disabled) {} else api("/api/system/check/last").then(renderCheck).catch(() => {});
  $("#rk-out").textContent = JSON.stringify(await api("/api/risk"), null, 2);
  const a = await api("/api/audit");
  $("#audit tbody").innerHTML = a.map(r => `<tr><td>${String(r.ts).slice(0, 19)}</td><td>${r.actor}</td><td>${r.action}</td><td class="muted">${esc(r.detail).slice(0, 160)}</td></tr>`).join("");
}
$("#rk-kill").onclick = async () => { if (confirm("Stop all new orders now?")) { await api("/api/risk/kill", { method: "POST" }); loadRisk(); } };
$("#rk-reset").onclick = async () => { await api("/api/risk/reset", { method: "POST" }); loadRisk(); };

function liveBanner(feed, rows) {
  const b = $("#live-banner"); const any = Object.values(rows || {})[0];
  if (feed.status === "waiting_for_login") {
    b.hidden = false;
    b.innerHTML = `Upstox login needed today (Upstox logins expire at 3:30 AM). Showing stored data${any && any.ts ? " up to " + any.ts.slice(0, 16) : ""}. <button class="sm" id="banner-login">Log in</button>`;
    $("#banner-login").onclick = () => $$("#tabs button").find(x => x.dataset.tab === "data").click();
  } else if (feed.status !== "connected") { b.hidden = false; b.textContent = `Upstox feed: ${feed.status}${feed.error ? " - " + feed.error : ""}`; }
  else b.hidden = true;
}

// ---------------------------------------------------------------- Upstox
async function loadUpstox() {
  try {
    const u = await api("/api/upstox/status");
    const f = u.feed;
    $("#ux-badge").innerHTML = !u.configured ? `<span class="red">not configured</span>` :
      u.logged_in ? `<span class="green">connected${u.account?.name ? " · " + esc(u.account.name) : ""}</span>` : `<span class="amber">login needed today</span>`;
    $("#ux-info").innerHTML = !u.configured
      ? `Add <code>UPSTOX_API_KEY</code> and <code>UPSTOX_API_SECRET</code> to <code>.env</code> (create an app at upstox.com/developer/apps with redirect URL <code>${esc(u.redirect_uri)}</code>), then restart.`
      : `Live feed: <b>${u.live_connector}</b>${f ? ` · ${f.status} · ${f.ticks} ticks · ${f.symbols} symbols${f.seconds_since_last_message != null ? ` · last tick ${f.seconds_since_last_message}s ago` : ""}${f.error ? ` · <span class="red">${esc(f.error)}</span>` : ""}` : ""}
         · orders: <b>${u.trading_mode === "live" && u.broker === "upstox" ? '<span class="red">LIVE via Upstox</span>' : "paper"}</b>
         ${u.live_connector !== "upstox" ? ` · set <code>LIVE_CONNECTOR=upstox</code> in .env to use the live feed` : ""}`;
    $("#ux-login").disabled = !u.configured;
  } catch (e) { $("#ux-badge").innerHTML = `<span class="red">${esc(e.message)}</span>`; }
}
$("#ux-login").onclick = async () => { try { const { url } = await api("/api/upstox/login-url", { method: "POST" }); location.href = url; } catch (e) { alert(e.message); } };
$("#ux-logout").onclick = async () => { await api("/api/upstox/logout", { method: "POST" }); loadUpstox(); };
$("#ux-token-go").onclick = async () => { try { await api("/api/upstox/token", { json: { access_token: $("#ux-token").value } }); $("#ux-token").value = ""; loadUpstox(); } catch (e) { alert(e.message); } };
if (new URLSearchParams(location.search).get("upstox") === "connected") {
  history.replaceState(null, "", "/"); setTimeout(() => $$("#tabs button").find(b => b.dataset.tab === "data").click(), 300);
}

// ---------------------------------------------------------------- boot
initChart(); resumeCheck(); loadWatchNote(); health(); setInterval(health, 30000); connectWS(); loadCalls(); setInterval(loadCalls, 15000); loadStrategySelects();
api("/api/live/status").then(s => s.rows && renderWatch(s.rows, s.sim_day)).catch(() => {});
